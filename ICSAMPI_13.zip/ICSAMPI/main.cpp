#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"
#include "Contador.h"

using namespace std;
using namespace cv;

int main(){
    cout<< "Identificación y conteo de semillas de ajo mediante procesamiento de imgenes"<<endl;
    //string dir("/home/os/Pictures/Fondos/birds.jpg");
    //string dir("/home/os/Pictures/Fondos/lead_960.jpg");
    //0234   y 0220, 0289
    //string dir("/home/os/Documents/IP_1(copy).JPG");
    //string dir("/home/os/Documents/apertura-elipse1-3.png");
    string dir("/home/os/Documents/p-c.png");
    Gestor g(dir);
    g.cargarImagen();

    if(!(g.obtenerImagen().empty())){
        Mat original=g.obtenerImagen();
        /*Filtros f;
        Mat grises=f.e_Grises(original);
        g.visualizar(grises);
        //f.histograma(original, 3);
        Mat bina=f.binarizacion(grises, 200);
        g.visualizar(bina);
        Mat morf=f.apertura(bina);
        //g.visualizar(morf);
        Mat dil=f.dilatacion(bina);*/

        //g.guardarImagen(grises, "/home/os/Documents/Proyectos/Proyecto_TT/Pruebas/grises.jpg");
        //g.guardarImagen(bin1, "/home/os/Documents/Proyectos/Proyecto_TT/Pruebas/grad-umb100-bin200.jpg");
        //g.guardarImagen(bin2, "/home/os/Documents/Proyectos/Proyecto_TT/Pruebas/grad-umb100-gris-bin200.jpg");

        //Mat img = imread("/home/os/Documents/IPP_1.JPG", IMREAD_COLOR);
        //Mat img = imread("/home/os/Documents/p-c.png", IMREAD_COLOR);
        Contador c;
        cout<< c.contar(original) << endl;
    }
    cout << "Fin del programa" << endl;
    return 0;
}
