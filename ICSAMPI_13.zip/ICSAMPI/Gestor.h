#ifndef GESTOR_H_INCLUDED
#define GESTOR_H_INCLUDED

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>

using namespace cv;
using namespace std;

class Gestor{
    private:
        Mat imgOriginal;
        String dir;

    public:
        Gestor(String directorio);
        Gestor();
        Mat obtenerImagen();
        void establecerImagen(Mat imagen);
        void establecerDirectorio(String);
        void cargarImagen();
        void guardarImagen(Mat, String);
        void visualizar(Mat);
        ~Gestor();
};

#endif // GESTOR_H_INCLUDED
