#ifndef CONTADOR_H
#define CONTADOR_H

#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>

using namespace std;
using namespace cv;

class Contador{
    public:
        Contador();
        int contar(Mat img);
};

#endif // CONTADOR_H
