#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Filtros.h"

using namespace cv;
using namespace std;

Filtros::Filtros(){}

Filtros::~Filtros(){}

Mat Filtros::e_Grises(Mat image){
    Mat gray(image.rows, image.cols, CV_8UC1);
    for(int i = 0; i < image.rows; i++){
        for(int j = 0; j < image.cols; j++){
            Vec3b pixel = image.at<Vec3b>(i, j);
            //OpenCV usa el orden de color BGR
            uchar b = pixel[0];
            uchar g = pixel[1];
            uchar r = pixel[2];
            gray.at<uchar>(i, j) = (b + g + r) / 3;
        }
    }
    return gray;
}

void Filtros::histograma(Mat m, int color) {
    vector<Mat> bgr_planes; ///Separar la imagen en sus planos BGR.
    split( m, bgr_planes );
    int histSize = 256;
    float range[] = { 0, 256 } ;
    const float* histRange = { range };
    bool uniform = true; bool accumulate = false;
    Mat b_hist, g_hist, r_hist;
    int hist_w = 512; int hist_h = 400;
    int bin_w = cvRound((double) hist_w/histSize);
    Mat histImage(hist_h, hist_w, CV_8UC3, Scalar(0,0,0)); /// Se crea una imagen para mostrar los histogramas.

    if(color == 0){ ///azul
        ///Calculando los histogramas(matriz origen, num matrices, canal a medir, mascara(si no esta definido no se usa),
        ///objeto donde se almacena el hist, dimensionalidad del hist, num de contenedores, rango de valores a medir, tamaño uniforme, inicio en limpio)
        calcHist( &bgr_planes[0], 1, 0, Mat(), b_hist, 1, &histSize, &histRange, uniform, accumulate);
        ///normaliza el histograma(matriz entrada, matriz normalizada, limite sup, lim inf, tipo de normalizacion, matriz normalizada del mismo tipo que entrada, mascara opcional)
        normalize(b_hist, b_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
        ///dibujar para cada canal y mostrar histograma
        for( int i = 1; i < histSize; i++){
              line( histImage, Point( bin_w*(i-1), hist_h - cvRound(b_hist.at<float>(i-1)) ) ,Point( bin_w*(i), hist_h - cvRound(b_hist.at<float>(i)) ), Scalar( 255, 0, 0), 2, 8, 0  );
        }
    }else if(color == 1){ ///verde
        calcHist( &bgr_planes[1], 1, 0, Mat(), g_hist, 1, &histSize, &histRange, uniform, accumulate);
        normalize(g_hist, g_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
        for( int i = 1; i < histSize; i++){
              line(histImage, Point( bin_w*(i-1), hist_h - cvRound(g_hist.at<float>(i-1))) ,Point(bin_w*(i), hist_h - cvRound(g_hist.at<float>(i))), Scalar(0, 255, 0), 2, 8, 0);
        }
    }else if(color == 2){ ///rojo
        calcHist(&bgr_planes[2], 1, 0, Mat(), r_hist, 1, &histSize, &histRange, uniform, accumulate);
        normalize(r_hist, r_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
        for( int i = 1; i < histSize; i++){
              line(histImage, Point( bin_w*(i-1), hist_h - cvRound(r_hist.at<float>(i-1))) ,Point(bin_w*(i), hist_h - cvRound(r_hist.at<float>(i))), Scalar(0, 0, 255), 2, 8, 0);
        }
    }else if(color == 3){ ///bgr
        calcHist(&bgr_planes[0], 1, 0, Mat(), b_hist, 1, &histSize, &histRange, uniform, accumulate);
        calcHist(&bgr_planes[1], 1, 0, Mat(), g_hist, 1, &histSize, &histRange, uniform, accumulate);
        calcHist(&bgr_planes[2], 1, 0, Mat(), r_hist, 1, &histSize, &histRange, uniform, accumulate);
        normalize(b_hist, b_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
        normalize(g_hist, g_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
        normalize(r_hist, r_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
        for( int i = 1; i < histSize; i++){
            line(histImage, Point(bin_w*(i-1), hist_h - cvRound(b_hist.at<float>(i-1))) ,Point(bin_w*(i), hist_h - cvRound(b_hist.at<float>(i))), Scalar(255, 0, 0), 2, 8, 0  );
            line(histImage, Point(bin_w*(i-1), hist_h - cvRound(g_hist.at<float>(i-1))) ,Point(bin_w*(i), hist_h - cvRound(g_hist.at<float>(i))), Scalar(0, 255, 0), 2, 8, 0);
            line(histImage, Point(bin_w*(i-1), hist_h - cvRound(r_hist.at<float>(i-1))) ,Point(bin_w*(i), hist_h - cvRound(r_hist.at<float>(i))), Scalar(0, 0, 255), 2, 8, 0);
        }
    }
    namedWindow("Histograma", WINDOW_AUTOSIZE );
    imshow("Histograma", histImage);
    waitKey(0);
}

Mat Filtros::recortarImg(Mat img, int largo, int alto){
    //cout <<"tamImagen: "<<img.size<< endl;
    //cout <<"cols: "<<img.cols<<", "<<img.rows<< endl;
    Rect corte(0,0,largo, alto);
    Mat recortada = img(corte);
    return recortada;
}

Mat Filtros::umbralizacion(Mat img, int umbral_b, int umbral_g, int umbral_r){
    Mat binarizada = Mat::zeros(img.size(), img.type());
    for(int i = 0; i < img.rows; i++){
        for(int j = 0; j < img.cols; j++){
            Vec3b pixel = img.at<Vec3b>(i, j);
            int b=pixel.val[0];
            int g=pixel.val[1];
            int r=pixel.val[2];
            if(b>umbral_b){
                pixel.val[0]=255;
            }if(g>umbral_g){
                pixel.val[1]=255;
            }if(r>umbral_r){
                pixel.val[2]=255;
            }
            binarizada.at<Vec3b>(i, j) = pixel;
        }
    }
    return binarizada;
}

Mat Filtros::binarizacion(Mat img, int umbral){
    Mat binarizada = Mat::zeros(img.size(), img.type());
    for(int i = 0; i < img.rows; i++){
        for(int j = 0; j < img.cols; j++){
            Vec3b pixel = img.at<Vec3b>(i, j);
            int b=pixel.val[0];
            if(b>umbral){
                pixel.val[0]=255;
                pixel.val[1]=255;
                pixel.val[2]=255;
            }else{
                pixel.val[0]=0;
                pixel.val[1]=0;
                pixel.val[2]=0;
            }
            binarizada.at<Vec3b>(i, j) = pixel;
        }
    }
    return binarizada;

    /*Mat binarizada;
    //adaptiveThreshold(img, binarizada, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 3, 0);
    threshold(img, binarizada, 50, 255, THRESH_BINARY | THRESH_OTSU);
    return binarizada;*/
}

Mat Filtros::gradiente(Mat img){
    Mat grises;
    //cvtColor(img, img, COLOR_BGR2GRAY);
    /*Mat dx, dy;
    Sobel(img, dx, CV_32F, 1,0);
    Sobel(img, dx, CV_32F, 0,1);
    Mat angle, mag;
    cartToPolar(dx, dy, mag, angle);
    return angle;*/

    Mat grad_x, grad_y, grad;
    Mat abs_grad_x, abs_grad_y;
    Sobel(img, grad_x, CV_16S, 1, 0, 3, 1, 0, BORDER_DEFAULT );
    convertScaleAbs(grad_x, abs_grad_x );
    Sobel(img, grad_y, CV_16S, 0, 1, 3, 1, 0, BORDER_DEFAULT );
    convertScaleAbs( grad_y, abs_grad_y);
    addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0, grad);
    return grad;
}

Mat Filtros::apertura(Mat img){
    //Mat kernelAux = {{0,1,0}, {1,1,1}, {1,1,1}, {1,1,1}, {0,1,0}};
    Mat apertura, kernel=getStructuringElement(MORPH_RECT, Size(2,2));
    cout << "elemento estructurante" << kernel << endl;
    morphologyEx(img, apertura, MORPH_OPEN, kernel);
    namedWindow("apertura", WINDOW_AUTOSIZE);
    imshow("apertura", apertura);
    waitKey(0);
    return apertura;
}

Mat Filtros::cierre(Mat img){
    Mat cierre, kernel=getStructuringElement(MORPH_RECT, Size(5,5));
    morphologyEx(img, cierre, MORPH_CLOSE, kernel);
    return cierre;
}

Mat Filtros::dilatacion(Mat img){
    Mat dil, kernel=getStructuringElement(MORPH_ELLIPSE, Size(3,5));
    dilate(img, dil, kernel);
    namedWindow("dilatacion", WINDOW_AUTOSIZE);
    imshow("dilatacion", dil);
    waitKey(0);
    return dil;
}

Mat Filtros::erosion(Mat img){
    Mat er, kernel=getStructuringElement(MORPH_RECT, Size(5,5));
    erode(img, er, kernel);
    return er;
}

Mat Filtros::grad_morf(Mat img){
    Mat grad, kernel=getStructuringElement(MORPH_RECT, Size(5,5));
    morphologyEx(img, grad, MORPH_GRADIENT, kernel);
    return grad;
}
