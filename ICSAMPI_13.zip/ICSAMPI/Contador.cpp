//#include "Contador.h"

#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include <opencv2/opencv.hpp>
//#pragma comment(lib, "opencv_world331.lib")
#include <iostream>
#include <vector>
#include "Contador.h"

using namespace std;
using namespace cv;

Contador::Contador(){}

int Contador::contar(Mat imagen){
    Mat img;
    cvtColor(imagen, img, COLOR_BGR2GRAY);
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    findContours(img, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0));
    vector<double> areas(contours.size());
    for(int i = 0; i < contours.size(); i++){
        areas[i] = contourArea(contours[i]);
    }

    return contours.size();
}
