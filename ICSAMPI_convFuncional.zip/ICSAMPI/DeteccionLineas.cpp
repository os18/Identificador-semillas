#include "DeteccionLineas.h"
#include "Gestor.h"

DeteccionLineas::DeteccionLineas(){}

Mat DeteccionLineas::transformada_Hough(Mat img){
    Mat img_canny, imagen, img_hough;
    Canny(img, img_canny, 100, 200, 3);// Edge detection
    Gestor g;
    g.visualizar(img_canny, "Canny");
    cvtColor(img_canny, imagen, COLOR_GRAY2BGR);
    img_hough = imagen.clone();
    vector<Vec4i> linesP;
    HoughLinesP(img_canny, linesP, 1, CV_PI/180, 10, 50, 10 ); // runs the detection
    for(size_t i=0; i<linesP.size(); i++){ // Draw the lines
        Vec4i l=linesP[i];
        line(img_hough, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(0,0,255), 3, LINE_AA);
    }
    return img_hough;
}
