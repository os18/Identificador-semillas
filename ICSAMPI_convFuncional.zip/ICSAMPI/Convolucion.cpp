#include "Convolucion.h"

Convolucion::Convolucion(Mat img){
    imagenOriginal = img.clone();
}

void Convolucion::asignarMatriz(int k[dim][dim]){
    for(int i=0; i<dim; i++){
        for(int j=0; j<dim; j++){
            kernel[i][j]=k[i][j];
        }
    }
}

void Convolucion::convolucionMatriz(int canal){ //canal=> 0,1 o 2
    kleng=length(kernel);
    mitad=length(kernel) / 2;
    cout<<"kleng: "<<kleng<<endl;
    cout<<"kleng mitad: "<<mitad<<endl;
    cout<<"tam img rows: "<<imagenOriginal.rows<<endl;
    cout<<"tam img cols: "<<imagenOriginal.cols<<endl;
    long acumulador;
    primerCanal=canal;
    //Mat nueva(imagenOriginal.size(), CV_32FC3);
    long matrizNueva[imagenOriginal.rows][imagenOriginal.cols];

    for(int ii=0; ii<imagenOriginal.rows; ii++){
        for(int jj=0; jj<imagenOriginal.cols; jj++){
            int fragImg[dim][dim]={0};
            obtener_FragImg(fragImg, ii, jj);
            acumulador=0;
            for(int x=0; x<kleng; x++){
                for(int y=0; y<kleng; y++){
                    acumulador+=(kernel[x][y]*fragImg[x][y]);
                }
            }
            acumulador/=divisor;
            matrizNueva[ii][jj]=acumulador;
            cout<<matrizNueva[ii][jj]<<" ";
            //nueva.at<Vec3f>(i, j) = pixel;
            //cout<<ii<<" "<<jj<<endl;
        }
        cout<<endl;
    }
}

void Convolucion::obtener_FragImg(int matriz[dim][dim], int ii, int jj){
    int xx=0, yy=0;
    for(int i = ii-(kleng-1)/2; i <= ii+(kleng-1)/2; i++){
        for(int j=jj-(kleng-1)/2; j <= jj+(kleng-1)/2; j++){
            if((j<0 || i<0) || (i>=imagenOriginal.rows || j>=imagenOriginal.cols)){
            	matriz[xx][yy] = 0;
            }else{
            	Vec3b pixel = imagenOriginal.at<Vec3b>(i, j);
            	matriz[xx][yy] = pixel.val[primerCanal];
            }
            yy++;
        }
        yy=0;
        xx++;
    }
    //imprimir_matriz(matriz);
    //cout<<endl;
}

void Convolucion::imprimir_matriz(int matriz[dim][dim]){
    for(int i=0; i<dim; i++){
        for(int j=0; j<dim; j++){
            cout<<matriz[i][j]<<" ";
        }
        cout<<endl;
    }
}

void Convolucion::normalizar(){
    ///calcular maximo
    for(int x=0; x<tam; x++){

    }
}
