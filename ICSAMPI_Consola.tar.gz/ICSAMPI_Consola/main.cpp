#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>

using namespace cv;
using namespace std;

class Gestor{
    private:
        Mat imgOriginal;
        String dir;

    public:
        Gestor(String directorio);
        Mat obtenerImagen();
        void establecerImagen(Mat imagen);
        void establecerDirectorio(String directorio);
        void cargarImagen();
        Mat construirOrtoimagen();
        void visualizar();
        ~Gestor();
};

    Gestor::Gestor(String directorio){
        dir=directorio;
    }

    Gestor::~Gestor(){} /*dctor*/

    Mat Gestor::obtenerImagen(){
        return imgOriginal;
    }

    void Gestor::establecerImagen(Mat imagen){
        imgOriginal=imagen;
    }

    void Gestor::establecerDirectorio(String directorio){
        dir=directorio;
    }

    void Gestor::cargarImagen(){
        imgOriginal = imread( dir, IMREAD_COLOR ); // Read the file
        if(imgOriginal.empty() ){
            cout <<  "Could not open or find the image" << endl ;
        }
    }

    Mat Gestor::construirOrtoimagen(){}

    void Gestor::visualizar(){
        Mat imgActual=obtenerImagen();
        namedWindow( "Imagen", WINDOW_AUTOSIZE ); // Create a window for display.
        imshow( "Imagen", imgActual );                // Show our image inside it.
        waitKey(0); // Wait for a keystroke in the window
    }

    int main(){
        cout<< "Identificación y conteo de semillas de ajo mediante procesamiento de imgenes"<<endl;
        cout<< "Seleccionando imagen. Introduce el directorio de la imagen "<<endl;
        cout << "Fin del programa1" << endl;
        String dir("/home/os/Pictures/Fondos/birds.jpg");
        Gestor g(dir);
        g.cargarImagen();
        if(!(g.obtenerImagen().empty())){
           g.visualizar();
        }

        cout << "Fin del programa" << endl;
        return 0;
    }
