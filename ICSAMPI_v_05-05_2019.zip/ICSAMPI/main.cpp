#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"
#include "Convolucion.h"

using namespace std;
using namespace cv;

int main(){
    string dir("../ICSAMPI/img/parcela/Im1.JPG");
    Gestor ge(dir);
    ge.cargarImagen();

    if(!(ge.obtenerImagen().empty())){
        Mat parcela=ge.obtenerImagen();
        ge.visualizar(parcela, "Parcela");

        Filtros f;
        //f.imprimir_matriz(parcela, 2);
        ///G
        int matriz[][5]={{193, 215, 214, 206, 192},
                         {216, 247, 240, 236, 237},
                         {213, 243, 243, 237, 242},
                         {174, 211, 243, 249, 240},
                         {144, 182, 232, 237, 218}};
        Convolucion conv(parcela);
        conv.asignarMatriz(matriz);
        conv.convolucionMatriz(1);
    }
    cout << "Fin del programa" << endl;
    return 0;
}

