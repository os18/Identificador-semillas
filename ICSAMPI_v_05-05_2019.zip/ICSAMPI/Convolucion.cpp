#include "Convolucion.h"

Convolucion::Convolucion(Mat img){
    imagenOriginal = img.clone();
}

void Convolucion::asignarMatriz(int k[dim][dim]){
    for(int i=0; i<dim; i++){
        for(int j=0; j<dim; j++){
            kernel[i][j]=k[i][j];
        }
    }
}

void Convolucion::convolucionMatriz(int canal){ //canal=> 0,1 o 2
    kleng=length(kernel);
    mitad=length(kernel) / 2;
    /*cout<<"kleng: "<<kleng<<endl;
    cout<<"kleng mitad: "<<mitad<<endl;
    cout<<"tam img rows: "<<imagenOriginal.rows<<endl;
    cout<<"tam img cols: "<<imagenOriginal.cols<<endl;*/
    long acumulador;
    Mat nueva(imagenOriginal.size(), CV_32SC3);
    //long matrizNueva[imagenOriginal.rows][imagenOriginal.cols];

    for(int ii=0; ii<imagenOriginal.rows; ii++){
        for(int jj=0; jj<imagenOriginal.cols; jj++){
            int fragImg[dim][dim]={0};
            obtener_FragImg(fragImg, ii, jj, canal);
            acumulador=0;
            for(int x=0; x<kleng; x++){
                for(int y=0; y<kleng; y++){
                    acumulador+=(kernel[x][y]*fragImg[x][y]);
                }
            }
            acumulador/=divisor;
            //matrizNueva[ii][jj]=acumulador;
            //cout<<matrizNueva[ii][jj]<<" ";
            nueva.at<long>(ii, jj) = acumulador;
            //cout<<ii<<" "<<jj<<endl;
        }
        //cout<<endl;
    }
    imprimir(nueva);
    normalizar(nueva, canal);
}

void Convolucion::obtener_FragImg(int matriz[dim][dim], int ii, int jj, int canal){
    int xx=0, yy=0;
    for(int i = ii-(kleng-1)/2; i <= ii+(kleng-1)/2; i++){
        for(int j=jj-(kleng-1)/2; j <= jj+(kleng-1)/2; j++){
            if((j<0 || i<0) || (i>=imagenOriginal.rows || j>=imagenOriginal.cols)){
            	matriz[xx][yy] = 0;
            }else{
            	Vec3b pixel = imagenOriginal.at<Vec3b>(i, j);
            	matriz[xx][yy] = pixel.val[canal];
            }
            yy++;
        }
        yy=0;
        xx++;
    }
    //imprimir_matriz(matriz);
    //cout<<endl;
}

void Convolucion::imprimir_matriz(int matriz[dim][dim]){
    for(int i=0; i<dim; i++){
        for(int j=0; j<dim; j++){
            cout<<matriz[i][j]<<" ";
        }
        cout<<endl;
    }
    cout << endl;
}

void Convolucion::imprimir(Mat img){
    cout << endl << endl;
    for(int i=0; i<img.rows; i++){
        for(int j=0; j<img.cols; j++){
            long num = img.at<long>(i, j);
            cout <<" "<<num;
        }
        cout <<endl;
    }
    cout <<endl;
}

void Convolucion::normalizar(Mat matrizImg, int canal){
    ///calcular maximo
    long maximo=funcion_max(matrizImg);
    for(int x=0; x<matrizImg.rows; x++){
        for(int y=0; y<matrizImg.cols; y++){
            long valor = matrizImg.at<long>(x, y); ///obtener el valor de la matriz
            int res=(valor*255)/maximo; ///valor*255 / maximo
            cout <<res<<" ";
            ///agregar a la imagen en el canal determinado
        }
        cout <<endl;
    }
}

long Convolucion::funcion_max(Mat matrizImg){
    long mayor = matrizImg.at<long>(0, 0);
    for(int i=0; i<matrizImg.rows; i++){
        for(int j=0; j<matrizImg.cols; j++){
            long valor = matrizImg.at<long>(i, j);
            if(valor > mayor){
                mayor=valor;
            }
        }
    }
    return mayor;
}
