#include <iostream>
#include <string>
#include <opencv2/opencv.hpp>
#include "opencv2/opencv.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <opencv2/core/types_c.h>
#include <opencv2/xfeatures2d/nonfree.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include "Filtros.h"

using namespace std;
using namespace cv;

int main(int argc, char** argv){

    String dir = "/home/os/Documents/prueba.JPG";
    //imwrite(dir, fin_img);
    Mat imgtemp = imread(dir, IMREAD_COLOR); //abrir imgenes
    if(imgtemp.empty()){cout << "Could not open or find the image"<<endl;}

    Filtros f;
    ///f.imprimirRGB(imgtemp);
    ///namedWindow("Temp", WINDOW_AUTOSIZE );
    ///imshow("Temp", imgtemp);
    ///waitKey(0);

    Mat umbralizada = f.Umbralizacion(imgtemp, 50);
    ///f.imprimirRGB(umbralizada);
    ///namedWindow("umb", WINDOW_AUTOSIZE );
    ///imshow("umb", umbralizada);
    ///waitKey(0);

    Mat sngChan = Mat(umbralizada.rows, umbralizada.cols, CV_8UC1);
    for(int i=0; i<umbralizada.rows; i++){
        for(int j=0; j<umbralizada.cols; j++){
            Vec3b pixel = umbralizada.at<Vec3b>(i, j);
            sngChan.at<uchar>(i,j) = ((uchar)(pixel.val[2]));
            cout<<(int)((uchar)(pixel.val[2]))<< " ";
        }
        cout <<endl;
    }
    namedWindow("single channel", WINDOW_AUTOSIZE );
    imshow("single channel", sngChan);
    waitKey(0);

    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    findContours(sngChan, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE);
    vector<double> areas(contours.size());
    vector<double> perimeter(contours.size());

    for (int i = 0; i < contours.size(); i++){
        areas[i] = contourArea(contours[i]);
        perimeter[i] = arcLength(contours[i],true);
    }

    vector<Point2d> mass_centres(contours.size());

    for(int i = 0; i < contours.size(); i++){
        const Moments mu = moments(contours[i], false);
        mass_centres[i] = Point2d(mu.m10 / mu.m00, mu.m01 / mu.m00);
    }

    cout << "Num particles: " << contours.size() << endl;

    for(int i = 0; i < contours.size(); i++){
        cout << "area " << (i + 1) << ": " << areas[i] << endl;
        cout << "perimeter " << (i + 1) << ": " << perimeter[i] << endl;
    }


    for(int i = 0; i < contours.size(); i++){
        cout << "centre " << (i + 1) << ": " << mass_centres[i].x << " " << mass_centres[i].y << endl;
    }


    return 0;
}



/*
#include "opencv2/opencv.hpp"

using namespace cv;
using namespace std;

int main( int argc, char** argv ){
	Mat im = imread("/home/os/Documents/IdentificadorSemillas/img/blob.jpg", IMREAD_GRAYSCALE );

	// Setup SimpleBlobDetector parameters.
	SimpleBlobDetector::Params params;
	// Change thresholds
	params.minThreshold = 10;
	params.maxThreshold = 200;

	// Filter by Area.
	params.filterByArea = true;
	params.minArea = 50;
	// Filter by Circularity
	params.filterByCircularity = true;
	params.minCircularity = 0.1;
	// Filter by Convexity
	params.filterByConvexity = true;
	params.minConvexity = 0.87;
	// Filter by Inertia
	params.filterByInertia = true;
	params.minInertiaRatio = 0.01;
	// Storage for blobs
	vector<KeyPoint> keypoints;

    #if CV_MAJOR_VERSION < 3   // If you are using OpenCV 2
        // Set up detector with params
        SimpleBlobDetector detector(params);
        // Detect blobs
        detector.detect( im, keypoints);
    #else
        // Set up detector with params
        Ptr<SimpleBlobDetector> detector = SimpleBlobDetector::create(params);
        // Detect blobs
        detector->detect( im, keypoints);
    #endif
    // Draw detected blobs as red circles.
    // DrawMatchesFlags::DRAW_RICH_KEYPOINTS flag ensures
    // the size of the circle corresponds to the size of blob
	Mat im_with_keypoints;
	drawKeypoints( im, keypoints, im_with_keypoints, Scalar(0,0,255), DrawMatchesFlags::DRAW_RICH_KEYPOINTS );
	// Show blobs
	imshow("keypoints", im_with_keypoints );
	waitKey(0);
}
*/
