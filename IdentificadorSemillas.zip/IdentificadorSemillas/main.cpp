//  main.cpp
//  learnopencv
//
//  Created by Efren on 5/24/19.
//  Copyright © 2019 Efren. All rights reserved.
/*
#include <iostream>
#include <string>
#include <opencv2/opencv.hpp>
#include "opencv2/opencv.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <opencv2/core/types_c.h>
#include <opencv2/xfeatures2d/nonfree.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include "Filtros.h"

using namespace std;
using namespace cv;
ofstream myfile;

int main(int argc, char** argv){
    double dou;
    Mat bgr[3];   //destination array
    Mat img = imread("/home/os/Documents/IdentificadorSemillas/img/IP_3.JPG");
    if(img.empty()){
        cout << "Error loading the image" << endl;
        return -1;
    }

    Mat nrate1 = Mat(img.size[0], img.size[1], CV_64F);
    Mat nrate2 = Mat(img.size[0], img.size[1], CV_64F);
    Mat nrate3 = Mat(img.size[0], img.size[1], CV_64F);
    Mat allcha = Mat_<double>(img.size[0], img.size[1], CV_64F);
    split(img,bgr); //split source

    for(int i=0; i<img.size[0]; i++){
        for(int j=0; j<img.size[1]; j++){
            nrate1.at<double>(i,j) = (double)(bgr[0].at<uchar>(i,j)) / bgr[1].at<uchar>(i,j);
            nrate2.at<double>(i,j) = (double)(bgr[0].at<uchar>(i,j)) / bgr[2].at<uchar>(i,j);
            nrate3.at<double>(i,j) = (double)(bgr[1].at<uchar>(i,j)) / bgr[2].at<uchar>(i,j);
        }
    }

    double min, max;
    cv::minMaxLoc(nrate1, &min, &max);;
    myfile<< min; myfile<< " =min \n";
    myfile<< max; myfile<< " =max \n";

    for(int i=0; i<img.size[0]; i++){
        for(int j=0; j<img.size[1]; j++){
            if(nrate1.at<double>(i,j) > 1.0) nrate1.at<double>(i,j) = 1.0 / nrate1.at<double>(i,j);
            if(nrate2.at<double>(i,j) > 1.0) nrate2.at<double>(i,j) = 1.0 / nrate2.at<double>(i,j);
            if(nrate3.at<double>(i,j) > 1.0) nrate3.at<double>(i,j) = 1.0 / nrate3.at<double>(i,j);
        }
    }

    cv::minMaxLoc(nrate1, &min, &max);;
    myfile<< min; myfile<< " =min \n";
    myfile<< max; myfile<< " =max \n";

    double thes;
    thes=0.90;
    int thers;
    thers=200;

    for (int i=0; i<img.size[0]; i++){
        for(int j=0; j<img.size[1]; j++){
            if((nrate1.at<double>(i,j)>thes)&&(nrate2.at<double>(i,j)>thes)&&(nrate3.at<double>(i,j)>thes)&&((bgr[0].at<uchar>(i,j))>thers)&&((bgr[1].at<uchar>(i,j))>thers)&&((bgr[2].at<uchar>(i,j))>thers)){
                nrate1.at<double>(i,j)=255;
                nrate2.at<double>(i,j)=255;
                nrate3.at<double>(i,j)=255;
            }else{
                nrate1.at<double>(i,j)=0;
                nrate2.at<double>(i,j)=0;
                nrate3.at<double>(i,j)=0;
            }
        }
    }

    cv::minMaxLoc(nrate1, &min, &max);;
    myfile<< min; myfile<< " =min \n";
    myfile<< max; myfile<< " =max \n";

    dou=bgr[0].at<uchar>(0,100);
    myfile<< dou; myfile<< "\n";
    dou=bgr[1].at<uchar>(0,100);
    myfile<< dou; myfile<< "\n";
    dou=nrate1.at<double>(0,100);
    myfile<< dou; myfile<< "\n";

    vector<Mat> channels;
    channels.push_back(nrate1);
    channels.push_back(nrate2);
    channels.push_back(nrate3);
    Mat fin_img;
    merge(channels, fin_img);

    namedWindow("My Window", 2);
    imshow("My Window", fin_img);
    cv::waitKey(0);

    /// //////////////////////////////////////////
    /*cout<<"channels_____________"<<fin_img.channels()<<endl;

    String dir = "/home/os/Documents/temp.JPG";
    imwrite(dir, fin_img);
    Mat imgtemp = imread(dir, IMREAD_COLOR); //abrir imgenes
    if(imgtemp.empty()){cout << "Could not open or find the image"<<endl;}

    Filtros f;

    Mat binary;
    threshold(fin_img, binary, 50, 255, THRESH_BINARY);
    f.imprimirRGB(binary);
    namedWindow("OtraUmbr", WINDOW_AUTOSIZE );
    imshow("OtraUmbr", binary);
    waitKey(0);

    cout<<"Holiwis "<<endl<<endl;
    Mat img_gray;
    cvtColor(binary, img_gray, COLOR_BGR2GRAY);
    f.imprimirRGB(img_gray);
    namedWindow("OtraUmbr", WINDOW_AUTOSIZE );
    imshow("OtraUmbr", img_gray);
    waitKey(0);

    cout<<"Holiwis "<<endl<<endl;


    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    findContours(img_gray, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0));
    vector<double> areas(contours.size());

    for (int i = 0; i < contours.size(); i++)
        areas[i] = contourArea(contours[i]);

    vector<Point2d> mass_centres(contours.size());

    for (int i = 0; i < contours.size(); i++){
        const Moments mu = moments(contours[i], false);
        mass_centres[i] = Point2d(mu.m10 / mu.m00, mu.m01 / mu.m00);
    }

    cout << "Num particles: " << contours.size() << endl;
    for (int i = 0; i < contours.size(); i++)
        cout << "area " << (i + 1) << ": " << areas[i] << endl;

    for (int i = 0; i < contours.size(); i++)
        cout << "centre " << (i + 1) << ": " << mass_centres[i].x << " " << mass_centres[i].y << endl;

    return 0;
}
*/
