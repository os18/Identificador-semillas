#ifndef CLASES_H_INCLUDED
#define CLASES_H_INCLUDED

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>

using namespace cv;
using namespace std;

class Gestor{
    private:
        Mat imgOriginal;
        String dir;

    public:
        Gestor(String directorio);
        Mat obtenerImagen();
        void establecerImagen(Mat imagen);
        void establecerDirectorio(String);
        void cargarImagen();
        void guardarImagen(Mat, String);
        void visualizar(Mat);
        ~Gestor();
};

    Gestor::Gestor(String directorio){
        dir=directorio;
    }

    Gestor::~Gestor(){}

    Mat Gestor::obtenerImagen(){
        return imgOriginal;
    }

    void Gestor::establecerImagen(Mat imagen){
        imgOriginal=imagen;
    }

    void Gestor::establecerDirectorio(String directorio){
        dir=directorio;
    }

    void Gestor::cargarImagen(){
        imgOriginal = imread(dir, IMREAD_COLOR ); //abrir imgenes
        if(imgOriginal.empty() ){
            cout <<  "Could not open or find the image" << endl ;
        }
    }

    void Gestor::guardarImagen(Mat imagen, String directorio){
         //home/os/Documents/Proyectos/Proyecto_TT/Pruebas/Originales
         imwrite(directorio, imagen);
    }

    void Gestor::visualizar(Mat imagen){
        namedWindow("Imagen", WINDOW_AUTOSIZE );
        imshow("Imagen", imagen);
        waitKey(0);
    }


///////////////


class Filtros{
    public:
        Filtros();
        ~Filtros();
        Mat e_Grises(Mat);
        Mat ecualizacion(Mat);
        Mat convolucion(int, Mat);
        Mat binarizacion(Mat, int);
        Mat iluminacion(Mat, int);
        void histograma(Mat, int);
        void recortarImg(Mat, int, int);
};

Filtros::Filtros(){} //constructor

Filtros::~Filtros(){} //destructor

Mat Filtros::e_Grises(Mat image){
    Mat gray(image.rows, image.cols, CV_8UC1);
    for(int i = 0; i < image.rows; i++){
        for(int j = 0; j < image.cols; j++){
            Vec3b pixel = image.at<Vec3b>(i, j);
            //OpenCV usa el orden de color BGR
            uchar b = pixel[0];
            uchar g = pixel[1];
            uchar r = pixel[2];
            gray.at<uchar>(i, j) = (b + g + r) / 3;
        }
    }
    return gray;
}

void Filtros::histograma(Mat m, int color) {
    vector<Mat> bgr;
    split(m,bgr);
    int histTam = 256;
    float rango[] = {0, 256} ;
    const float* histRango = {rango};
    Mat obHist;

    if (color == 0){
        calcHist(&bgr[0], 1, 0, Mat(), obHist, 1, &histTam, &histRango, true, false);
    }else if(color == 1){
        calcHist(&bgr[1], 1, 0, Mat(), obHist, 1, &histTam, &histRango, true, false);
    }else if(color == 2){
        calcHist(&bgr[2], 1, 0, Mat(), obHist, 1, &histTam, &histRango, true, false);
    }else if(color == 3){
        calcHist(&bgr[0], 1, 0, Mat(), obHist, 1, &histTam, &histRango, true, false);
        calcHist(&bgr[1], 1, 0, Mat(), obHist, 1, &histTam, &histRango, true, false);
        calcHist(&bgr[2], 1, 0, Mat(), obHist, 1, &histTam, &histRango, true, false);
    }

    int bin_w = cvRound((double) 512/256);
    Mat histImagen(400, 512, CV_8UC3, Scalar(0,0,0));
    normalize(obHist, obHist, 0, histImagen.rows, NORM_MINMAX, -1, Mat());

    if (color == 0){
        for(int i = 1; i < 256; i++){
            line(histImagen, Point( bin_w*(i-1), 400 - cvRound(obHist.at<float>(i-1))), Point(bin_w*(i), 400 - cvRound(obHist.at<float>(i))), Scalar(255,0,0), 2, 8, 0);
        }
    }else if(color == 1){
        for(int i = 1; i < 256; i++){
            line(histImagen, Point( bin_w*(i-1), 400 - cvRound(obHist.at<float>(i-1))), Point(bin_w*(i), 400 - cvRound(obHist.at<float>(i))), Scalar(0,255,0), 2, 8, 0);
        }
    }else if(color == 2){
        for(int i = 1; i < 256; i++){
            line(histImagen, Point( bin_w*(i-1), 400 - cvRound(obHist.at<float>(i-1))), Point(bin_w*(i), 400 - cvRound(obHist.at<float>(i))), Scalar(0,0,255), 2, 8, 0);
        }
    }else if(color == 3){
        for(int i = 1; i < 256; i++){
            line(histImagen, Point( bin_w*(i-1), 400 - cvRound(obHist.at<float>(i-1))), Point(bin_w*(i), 400 - cvRound(obHist.at<float>(i))), Scalar(255,0,0), 2, 8, 0);
            line(histImagen, Point( bin_w*(i-1), 400 - cvRound(obHist.at<float>(i-1))), Point(bin_w*(i), 400 - cvRound(obHist.at<float>(i))), Scalar(0,255,0), 2, 8, 0);
            line(histImagen, Point( bin_w*(i-1), 400 - cvRound(obHist.at<float>(i-1))), Point(bin_w*(i), 400 - cvRound(obHist.at<float>(i))), Scalar(0,0,255), 2, 8, 0);
        }
    }
    imshow("Histograma", histImagen);
    waitKey(0);
}



void Filtros::recortarImg(Mat img, int largo, int alto){
    cout <<"tamImagen: "<<img.size<< endl;
    cout <<"cols: "<<img.cols<<", "<<img.rows<< endl;
    Rect corte(0,0,largo, alto);
    Mat recortada = img(corte);
    imshow("Recortada", recortada);
    waitKey(0);
}

Mat Filtros::binarizacion(Mat img, int umbral){
    threshold(img, img, umbral, 255, THRESH_BINARY);
    imshow("binarizada", img);
    waitKey(0);
    return img;
}

Mat Filtros::iluminacion(Mat img, int vIlum){
    //pasar a espacio de color LAb
    Mat img_enLab;
    cvtColor(img, img_enLab, COLOR_BGR2Lab);
    //extraer el canal L
    vector<Mat> lab_canales(3);
    split(img_enLab, lab_canales);

    // aplicar CLAHE algoritmo al canal L
    Ptr<CLAHE> clahe = createCLAHE();
    clahe->setClipLimit(4);
    Mat dst;
    clahe->apply(lab_canales[0], dst);

    // Devuelve los colores a los canales LAB
    dst.copyTo(lab_canales[0]);
    merge(lab_canales, img_enLab);

   // convierte a RGB
   Mat image_clahe;
   cvtColor(img_enLab, image_clahe, COLOR_Lab2BGR);

   // display the results  (you might also want to see lab_planes[0] before and after).
   imshow("image original", img);
   imshow("image CLAHE", image_clahe);
   waitKey(0);
    return image_clahe;
}


#endif // CLASES_H_INCLUDED
