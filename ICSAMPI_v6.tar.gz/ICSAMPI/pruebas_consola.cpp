#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"
//#include "Clases.h"
using namespace std;
using namespace cv;
/*
int main(){
    cout<< "Identificación y conteo de semillas de ajo mediante procesamiento de imgenes"<<endl;
    //string dir("/home/os/Pictures/Fondos/birds.jpg");
    //string dir("/home/os/Pictures/Fondos/lead_960.jpg");
    string dir("/home/os/Documents/Proyectos/Proyecto_TT/Pruebas/Originales/DJI_0234.JPG");
    Gestor g(dir);
    g.cargarImagen();

    if(!(g.obtenerImagen().empty())){
         Mat original=g.obtenerImagen();
         g.visualizar(original);
         Filtros f;
         Mat grises2=f.e_Grises(original);
         g.visualizar(grises2);
         f.histograma(grises2,0);
         Mat binarizada2=f.binarizacion(grises2, 210);
         string direcorio("/home/os/Documents/Proyectos/Proyecto_TT/Pruebas/grises-binarizacion_u200_2.JPG");
         g.guardarImagen(binarizada2, direcorio);
    }
    cout << "Fin del programa" << endl;
    return 0;
}
*/
