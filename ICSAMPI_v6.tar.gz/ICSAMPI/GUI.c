#include <gtk/gtk.h>
#include <stdbool.h>

char *archivo;
bool sigVent=false;

static void open_dialog(GtkWidget *btn_continuar, gpointer ventana){
    GtkWidget *dialog;
    dialog=gtk_file_chooser_dialog_new("Selecciona una imagen", GTK_WINDOW(ventana), GTK_FILE_CHOOSER_ACTION_OPEN,("_CANCEL"), GTK_RESPONSE_CANCEL, ("_OPEN"),GTK_RESPONSE_ACCEPT, NULL);
    gtk_widget_show_all(dialog);
    if(gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_OK){
        archivo = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));
        sigVent=true;
        g_print("%s\n", archivo);
    }else{
        GtkWidget *dial;
        GtkDialogFlags flags = GTK_DIALOG_DESTROY_WITH_PARENT;
        dial = gtk_message_dialog_new (NULL, flags, GTK_MESSAGE_ERROR, GTK_BUTTONS_CLOSE, "Para continuar selecciona una imagen");

        // Destroy the dialog when the user responds to it
        // (e.g. clicks a button)
        g_signal_connect_swapped (dial, "response", G_CALLBACK (gtk_widget_destroy), dial);
    }
    gtk_widget_destroy(dialog);
}

int main(int argc, char *argv[]) {
    GtkWidget *tabla_cont; //contenedor de los elementos (widget) en la ventana
    GtkWidget *ventana;
    GtkWidget *btn_continuar;
    GtkWidget *logo; //

    gtk_init(&argc, &argv);

    //crear ventana1
    ventana = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_position(GTK_WINDOW(ventana), GTK_WIN_POS_CENTER);
    gtk_window_set_default_size(GTK_WINDOW(ventana), 80, 40);
    //titulo de la ventana
    gtk_window_set_title(GTK_WINDOW(ventana), "Principal");
    //estableciendo el borde de la ventana
    gtk_container_set_border_width(GTK_CONTAINER(ventana), 5);

    //contenedor para los wigdet
    tabla_cont = gtk_grid_new();

    //se agrega el contenedor a la ventana
    gtk_container_add(GTK_CONTAINER(ventana),tabla_cont);

    //la imagen de logo de agrega en la primera fila
    logo = gtk_image_new_from_file ("/home/os/Documents/TT/logo_.png");
    gtk_grid_attach(GTK_GRID(tabla_cont),logo, 0,0,1,1);

    btn_continuar = gtk_button_new_with_label("Continuar");
    gtk_widget_set_size_request(btn_continuar, 15, 10);
    gtk_grid_attach(GTK_GRID(tabla_cont), btn_continuar,0,1,1,2);
    g_signal_connect(G_OBJECT(btn_continuar), "clicked", G_CALLBACK(open_dialog), NULL);

    g_signal_connect(G_OBJECT(ventana), "destroy", G_CALLBACK(gtk_main_quit), NULL);


    //mostrar
    gtk_widget_show_all(ventana);
    gtk_main();

    return 0;
}
