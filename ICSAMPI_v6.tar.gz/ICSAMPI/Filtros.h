#ifndef FILTROS_H_INCLUDED
#define FILTROS_H_INCLUDED
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>

using namespace cv;
using namespace std;

class Filtros{
    public:
        Filtros();
        ~Filtros();
        Mat e_Grises(Mat);
        Mat ecualizacion(Mat);
        Mat convolucion(int, Mat);
        Mat binarizacion(Mat, int);
        Mat iluminacion(Mat, int);
        void histograma(Mat, int);
//        void dibujarHistograma(Mat, int);
        void recortarImg(Mat, int, int);
};

Filtros::Filtros(){} //constructor

Filtros::~Filtros(){} //destructor

Mat Filtros::e_Grises(Mat image){
    Mat gray(image.rows, image.cols, CV_8UC1);
    for(int i = 0; i < image.rows; i++){
        for(int j = 0; j < image.cols; j++){
            Vec3b pixel = image.at<Vec3b>(i, j);
            //OpenCV usa el orden de color BGR
            uchar b = pixel[0];
            uchar g = pixel[1];
            uchar r = pixel[2];
            gray.at<uchar>(i, j) = (b + g + r) / 3;
        }
    }
    return gray;
}

void Filtros::histograma(Mat m, int color) {
    //Separar la imagen en sus planos BGR. Establecer el rango de valores entre 0 y 255 y crear objetos para guardar los histogramas
    //Calculando los histogramas(matriz origen, num matrices, canal a medir, mascara (si no esta definido no se usa), objeto donde se almacena el hist, dimensionalidad del hist, num de contenedores, rango de valores a medir, tamaño uniforme, inicio en limpio)
    // Se crea una imagen para mostrar los histogramas.
    //antes de dibujar, se normaliza el histograma(matriz entrada, matriz normalizada, limite sup, lim inf, tipo de normalizacion, matriz normalizada sera del mismo tipo que entrada, mascara opcional)
    //dibujar para cada canal y mostrar histograma

    vector<Mat> bgr_planes;
  split( m, bgr_planes );

  /// Establish the number of bins
  int histSize = 256;

  /// Set the ranges ( for B,G,R) )
  float range[] = { 0, 256 } ;
  const float* histRange = { range };

  bool uniform = true; bool accumulate = false;

  Mat b_hist, g_hist, r_hist;

  /// Compute the histograms:
  calcHist( &bgr_planes[0], 1, 0, Mat(), b_hist, 1, &histSize, &histRange, uniform, accumulate );

  // Draw the histograms for B, G and R
  int hist_w = 512; int hist_h = 400;
  int bin_w = cvRound( (double) hist_w/histSize );

  Mat histImage( hist_h, hist_w, CV_8UC3, Scalar( 0,0,0) );

  /// Normalize the result to [ 0, histImage.rows ]
  normalize(b_hist, b_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat() );

  /// Draw for each channel
  for( int i = 1; i < histSize; i++ ){
      line( histImage, Point( bin_w*(i-1), hist_h - cvRound(b_hist.at<float>(i-1)) ) ,Point( bin_w*(i), hist_h - cvRound(b_hist.at<float>(i)) ), Scalar( 255, 0, 0), 2, 8, 0  );
  }

    namedWindow("Histograma", WINDOW_AUTOSIZE);
    imshow("Histograma", histImage);
    waitKey(0);
}

void Filtros::recortarImg(Mat img, int largo, int alto){
    cout <<"tamImagen: "<<img.size<< endl;
    cout <<"cols: "<<img.cols<<", "<<img.rows<< endl;
    Rect corte(0,0,largo, alto);
    Mat recortada = img(corte);
    imshow("Recortada", recortada);
    waitKey(0);
}

Mat Filtros::binarizacion(Mat img, int umbral){
    Mat binarizada = Mat::zeros(img.size(), img.type());
    for(int i = 0; i < img.rows; i++){
        for(int j = 0; j < img.cols; j++){
            Vec3b pixel = img.at<Vec3b>(i, j);
            int b=pixel.val[0];
            if(b>umbral){
                pixel.val[0]=255;
                pixel.val[1]=255;
                pixel.val[2]=255;
                binarizada.at<Vec3b>(i, j) = pixel;
            }else{
                pixel.val[0]=0;
                pixel.val[1]=0;
                pixel.val[2]=0;
                binarizada.at<Vec3b>(i, j) = pixel;
            }
        }
    }
    imshow("binarizada", binarizada);
    waitKey(0);
    return binarizada;
}

Mat Filtros::iluminacion(Mat img, int vIlum){
    Mat iluminada; //= Mat::zeros(img.size(), img.type());
    /*for(int i = 0; i < img.rows; i++){
        for(int j = 0; j < img.cols; j++){
            //Vec3b pixel = img.at<Vec3b>(i, j);
            /*int b=pixel.val[0]+vIlum;
            int g=pixel.val[1]+vIlum;
            int r=pixel.val[2]+vIlum;
            pixel.val[0]=b;
            pixel.val[1]=g;
            pixel.val[2]=r;
            iluminada.at<Vec3b>(i, j) = pixel;

        }
    }*/
    img.convertTo(iluminada, -1, 1, vIlum);
    return iluminada;
}

#endif // FILTROS_H_INCLUDED
