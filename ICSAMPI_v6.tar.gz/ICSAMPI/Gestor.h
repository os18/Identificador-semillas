#ifndef GESTOR_H_INCLUDED
#define GESTOR_H_INCLUDED
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>

using namespace cv;
using namespace std;

class Gestor{
    private:
        Mat imgOriginal;
        String dir;

    public:
        Gestor(String directorio);
        Mat obtenerImagen();
        void establecerImagen(Mat imagen);
        void establecerDirectorio(String);
        void cargarImagen();
        void guardarImagen(Mat, String);
        void visualizar(Mat);
        ~Gestor();
};

    Gestor::Gestor(String directorio){
        dir=directorio;
    }

    Gestor::~Gestor(){}

    Mat Gestor::obtenerImagen(){
        return imgOriginal;
    }

    void Gestor::establecerImagen(Mat imagen){
        imgOriginal=imagen;
    }

    void Gestor::establecerDirectorio(String directorio){
        dir=directorio;
    }

    void Gestor::cargarImagen(){
        imgOriginal = imread(dir, IMREAD_COLOR ); //abrir imgenes
        if(imgOriginal.empty() ){
            cout <<  "Could not open or find the image" << endl ;
        }
    }

    void Gestor::guardarImagen(Mat imagen, String directorio){
         //home/os/Documents/Proyectos/Proyecto_TT/Pruebas/Originales
         imwrite(directorio, imagen);
    }

    void Gestor::visualizar(Mat imagen){
        namedWindow("Imagen", WINDOW_AUTOSIZE );
        imshow("Imagen", imagen);
        waitKey(0);
    }


#endif // GESTOR_H_INCLUDED
