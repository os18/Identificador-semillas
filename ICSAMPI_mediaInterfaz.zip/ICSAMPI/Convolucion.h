#ifndef CONVOLUCION_H
#define CONVOLUCION_H

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <math.h>

#define dim 5
#define di2 3

using namespace cv;
using namespace std;

template <class T, std::size_t N>
size_t CountOf(const T (&array)[N]){return N;}

class Convolucion{
    private:
        Mat imagenOriginal;
        //double kernel[di2][dim]={{-1,1,1},{-1,-2,1},{-1,1,1}};
        //double kernel[di2][dim]={{-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1},{-1,-1,5,-1,-1},{-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1}};
        //double kernel[di2][dim]={{1,2,3,1,1},{2,7,11,7,2},{3,11,17,11,3},{2,7,11,7,1},{1,2,3,2,1}};
        //double kernel[di2][dim]={{1,1,1},{1,1,1},{1,1,1}};
        double kernel[di2][dim]={{-2,0,-2,0,-2},{0,-2,0,-2,0},{-2,0,-2,0,-2}};
        int divisor=1;
        int tam_kernel= CountOf(kernel[0]);

    public:
        Convolucion(Mat);
        Mat aplicar();
        int validar(int);
        void extraerMuestra(int, int, Vec3b [][dim]); //arreglo retornado por referencia
        void convolucionar(Vec3b[][dim], int[]); //arreglo retornado por referencia
};

#endif // CONVOLUCION_H
