#include <gtkmm-3.0/gtkmm.h>
#include <gtkmm-3.0/gtkmm/button.h>

#include <string>
#include "Gestor.h"
#include <iostream>

int main(int argc, char *argv[]){
    auto app = Gtk::Application::create(argc, argv,"Identificador_semillas");
    Gtk::Window ventana;
    ventana.set_default_size(1000, 600);
    ventana.set_border_width(12);

    Gtk::Grid grid;
    Gtk::Button btn_cargarImg, btn_expImag, btn_identificar, btn_almacenar;
    Gtk::Label contImg;
    Gtk::Image logo;
    Gtk::Image img_seleccionada;
    Gtk::IconView log;

    ventana.add(grid);


    /*grid.add(btn_cargarImg);
    grid.add(btn_expImag);
    grid.add(btn_identificar);
    grid.add(btn_almacenar);
    grid.attach(btn_cargarImg,1,1,20,10);
    grid.attach(btn_expImag, 1,2,20,10);
    grid.attach(btn_identificar,1,3,20,10);
    grid.attach(btn_almacenar,1,4,20,10);*/

    return app->run(ventana);
}
