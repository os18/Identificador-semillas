#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"

using namespace std;
using namespace cv;

Gestor::Gestor(){}

Gestor::Gestor(String directorio){
    dir=directorio;
}

Mat Gestor::obtenerImagen(){
    return imgOriginal;
}

void Gestor::establecerImagen(Mat imagen){
    imgOriginal=imagen;
}

void Gestor::establecerDirectorio(String directorio){
    dir=directorio;
}

void Gestor::cargarImagen(){
    imgOriginal = imread(dir, IMREAD_COLOR); //abrir imgenes
    if(imgOriginal.empty() ){
        cout << "Could not open or find the image" << endl ;
    }
}

void Gestor::guardarImagen(Mat imagen, String directorio){
    //home/os/Documents/Proyectos/Proyecto_TT/Pruebas/Originales
    imwrite(directorio, imagen);
}

void Gestor::visualizar(Mat imagen, String nombre){
    namedWindow(nombre, WINDOW_AUTOSIZE );
    imshow(nombre, imagen);
    waitKey(0);
}
