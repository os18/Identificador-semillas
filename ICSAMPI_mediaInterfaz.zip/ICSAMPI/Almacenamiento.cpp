#include "Almacenamiento.h"
#include <iostream>
#include <string>
#include <fstream>
#include <mysql/mysql.h>

#include <iostream>
#include <string>

using namespace std;

Almacenamiento::Almacenamiento(){}

void Almacenamiento::gestionBD_almacenar(string nImg, int conteo, int porcentaje){
    MYSQL *myData;
    // Intentar iniciar MySQL:
    if(!(myData = mysql_init(0))){
        cout << "Imposible crear el objeto mydata" <<endl;
    }else{
        cout << "se creó correctamente" <<endl;
    }
    const char* usuario = ("os");
    const char* clave = "fldsmdfr";
    const char* database_name = ("ICSAMPI");
    char consulta[] = "INSERT INTO Semilla_identificada (id_imgConteo, conteo, porcentaje) VALUES ('nImg'), ('conteo'), ('porcentaje')"; //img_conteo, conteo, porcentaje

    if(!mysql_real_connect(myData, "localhost", usuario, clave, database_name, MYSQL_PORT, NULL, 0)){
        cout << "Imposible conectar con servidor mysql en el puerto especificado" << MYSQL_PORT << endl;
        mysql_close(myData);
    }
    if(mysql_query(myData, consulta)){
        cout << "Creado exitoso" << endl;
        mysql_query(myData, consulta);
    }
}

void Almacenamiento::gestionBD_consulta(){}

void Almacenamiento::guardarInformacion(string dir, string nImg, string fecha, int conteo, double porcentaje){  //imgUtilizada, fecha, conteo, porcentaje
    fstream archivo;
    dir_archivo="/home/os/Documents/"+dir+".txt";
    archivo.open(dir_archivo, ios::out | ios::app);
    if(archivo.is_open()){//añadir los datos

    }else{
        cerr << "No se ha podido abrir el archivo" << endl;
        exit(1);
    }
    archivo.close();
}
