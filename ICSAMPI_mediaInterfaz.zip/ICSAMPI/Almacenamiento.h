#ifndef ALMACENAMIENTO_H
#define ALMACENAMIENTO_H

#include <iostream>
#include <string>

using namespace std;

class Almacenamiento{
    private:
        string dir_archivo="";

    public:
        Almacenamiento();
        void gestionBD_almacenar(string, int, int);
        void gestionBD_consulta();
        void guardarInformacion(string, string, string, int, double); //imgUtilizada, fecha, conteo, porcentaje
};

#endif // ALMACENAMIENTO_H
