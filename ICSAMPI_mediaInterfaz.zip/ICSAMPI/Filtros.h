#ifndef FILTROS_H_INCLUDED
#define FILTROS_H_INCLUDED

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>

using namespace std;
using namespace cv;

class Filtros{
    public:
        Filtros();
        Mat e_Grises(Mat);
        Mat Umbralizacion(Mat, int);
        Mat recortarImg(Mat, int, int);
        Mat negativo(Mat);
        Mat expansionLineal(int, int, Mat);
        Mat umbralizacion_otsu(Mat);
        void Histograma(double []);
        void Histograma_RGB(Mat);
        void calcularFrecuencias(Mat, int, double[]);
        int validar(int);
        int calcularMaximo(double []);
        int calcularMinimo(double []);
        int reajustarUmbral(int, double[]);
        int calcular_Umbral_Automatico(double []);

        ///_______
        int contar(Mat imagen);
        Mat erosion(Mat);
};

#endif // FILTROS_H_INCLUDED
