//#include <gtkmm-3.0/gtkmm.h>
//#include <gtkmm-3.0/gtkmm/button.h>

#include <string>
#include "Gestor.h"
#include <iostream>

/*

int main(int argc, char *argv[]){
    auto app = Gtk::Application::create(argc, argv,"Identificador_semillas");
    Gtk::Window ventana;
    ventana.set_default_size(1000, 600);
    ventana.set_border_width(12);

    //objetos necesarios
    Gtk::Grid grid;
    Gtk::Button btn_cargarImg, btn_expImag, btn_identificar, btn_almacenar;
    Gtk::Label contImg;
    Gtk::Frame f_vertical;
    Gtk::Image logo;
    Gtk::Image img_seleccionada;
    Gtk::IconView log;

    //personalizando los botones
    btn_cargarImg.add_pixlabel("/home/os/Documents/Proyectos/Proyecto_TT/ICSAMPI/imagenes/b1.png", "Seleccionar imagen");
    btn_expImag.add_pixlabel("/home/os/Documents/Proyectos/Proyecto_TT/ICSAMPI/imagenes/b2.png", "Ver imagen");
    btn_identificar.add_pixlabel("/home/os/Documents/Proyectos/Proyecto_TT/ICSAMPI/imagenes/b3.png", "Identificar semilla");
    btn_almacenar.add_pixlabel("/home/os/Documents/Proyectos/Proyecto_TT/ICSAMPI/imagenes/b4.jpg", "Almacenar resultados");

    //__



    ventana.add(grid);
    grid.add(btn_cargarImg);
    grid.add(btn_expImag);
    grid.add(btn_identificar);
    grid.add(btn_almacenar);
    grid.attach_next_to(btn_expImag, btn_cargarImg, Gtk::POS_BOTTOM, 2, 1);
    //grid.attach(btn_expImag,0, 1, 1, 1);
    grid.attach(btn_identificar, 0, 2, 1, 1);
    grid.attach(btn_almacenar,1, 1, 1, 1);
    ventana.show_all();

    return app->run(ventana);
}
*/
