#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"
#include "Contador.h"
#include "Convolucion.h"
#include "Almacenamiento.h"


using namespace std;
using namespace cv;

int main(){
    cout<< "Identificación y conteo de semillas de ajo mediante procesamiento de imgenes"<<endl;
    string dir("/home/os/Documents/TT/Presentacion/TT2/DJI_0234/6.jpg");
    //string dir("/home/os/Documents/TT/Presentacion/TT2/Conteo/C5.jpg");

    Gestor g(dir);
    g.cargarImagen();

    if(!(g.obtenerImagen().empty())){
        Mat original=g.obtenerImagen();
        Filtros f;
        g.visualizar(original, "Original");
        ///expansión lineal
        Mat exMan=f.expansionLineal(200,255, original);
        g.visualizar(exMan, "Expansion");
        ///umbralización otsu
        Mat umotsu_manual=f.umbralizacion_otsu(exMan);
        g.visualizar(umotsu_manual, "Umbralizacion");
        Mat x;
        cvtColor(umotsu_manual,x,COLOR_GRAY2RGB);
        //g.visualizar(x, " ");
        Mat neg=f.negativo(x);
        ///convolucion
        double kernel[9]={1,1,1,1,1,1,1,1,1};
        Convolucion cv(neg);
        cv.asignarMatriz(kernel);
        Mat con=cv.aplicar();
        //g.visualizar(con, "convolucion");
        Mat er=f.erosion(con);
        Mat bina=f.Umbralizacion(er, 220);
        Mat neg2=f.negativo(bina);
        double kernel2[9]={1,2,1,2,4,2,1,2,1};
        Convolucion cv2(neg2);
        cv2.asignarMatriz(kernel2);
        Mat con2=cv2.aplicar();
        g.visualizar(con2, "Convolucion");
        //Mat neg3=f.negativo(con2);
        //g.visualizar(neg3, "convolucion");
        ///conteo
        Contador c(bina,0,0);
        cout << "conteo: "<<c.contar(bina)<<endl;


        /*Almacenamiento a;
        a.gestionBD_almacenar("img", 10, 90);*/




    }
    cout << "Fin del programa" << endl;
    return 0;
}
