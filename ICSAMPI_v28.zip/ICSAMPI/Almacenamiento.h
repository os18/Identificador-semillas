#ifndef ALMACENAMIENTO_H
#define ALMACENAMIENTO_H

#include <iostream>
#include <string>
#include <mysql_connection.h>
#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>

#include <mysql/mysql.h>
#include <mysql/mysqld_error.h>

using namespace std;
using namespace sql;

class Almacenamiento{
    public:
        Almacenamiento();
        void gestionBD_almacenar(string, int, int);
};

#endif // ALMACENAMIENTO_H
