#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"
#include "Contador.h"
#include "Convolucion.h"
#include "Almacenamiento.h"

using namespace std;
using namespace cv;

int main(){
    cout<< "Identificación y conteo de semillas de ajo mediante procesamiento de imgenes"<<endl;
    //string dir("/home/os/Documents/TT/ReporteTT2_LaTeX/Imagenes/umbralizacionExpL-200-255_Otsu.jpg");
    //string dir("/home/os/Documents/Otras pruebas/Mascara_1-2_1-2_5-2_1-2_1.jpg");
    string dir("/home/os/Documents/TT/Pruebas/IP_6.JPG");
    //string dir("/home/os/Documents/TT/Pruebas/Conteo/1.jpg");
    //string dir("/home/os/Documents/TT/ReporteTT2_LaTeX/Imagenes/umbralizacionExpL-200-255_Otsu_imgP3.jpg");

    Gestor g(dir);
    g.cargarImagen();


    if(!(g.obtenerImagen().empty())){
        Mat original=g.obtenerImagen();
        Filtros f;
        g.visualizar(original, "Original");

        /*Contador cnt(original,0,0);
        cnt.Contar();
        cout<< "conteo: "<< cnt.getEuler() <<endl;*/

        double histograma[256]={0};
        f.calcularFrecuencias(original, 1, histograma);
        int r1=f.calcularMinimo(histograma);
        int r2=f.calcularMaximo(histograma);

        //Mat exl=f.expansionLineal(r1,r2,original);
        Mat ex=f.expansionLineal(250,255,original);
        g.visualizar(ex, "expansion");

        Mat umb=f.umbralizacion_otsu(ex);
        g.visualizar(umb, "umbralizacion otsu");

        /*double histograma2[256]={0};
        f.calcularFrecuencias(original, 1, histograma2);
        int uu=f.calcular_Umbral_Automatico(histograma2);
        Mat o=f.Umbralizacion(ex, uu);
        g.visualizar(o, "isodata");*/

        /*Convolucion c(umb);
        Mat conv=c.aplicar();
        g.visualizar(conv, "Convolucion");

        Mat aux=f.negativo(conv);
        g.visualizar(aux, "neg umbr");*/

        g.guardarImagen(ex, "/home/os/Documents/expL_man_IP6_250-255.jpg");
        g.guardarImagen(umb, "/home/os/Documents/IP6_umbraliz_expM.jpg");

        //Almacenamiento a;
        //a.gestionBD_almacenar("img_1", 100, 80);

    }
    cout << "Fin del programa" << endl;
    return 0;
}
