#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include <math.h>
#include <stdlib.h>
#include <vector>
#include <cmath>
#include <boost/tuple/tuple.hpp>
#include "gnuplot_i.hpp"
#include "Filtros.h"

#define length(x) (sizeof(x)/sizeof(x[0]))

using namespace cv;
using namespace std;

Filtros::Filtros(){}

Mat Filtros::e_Grises(Mat image){
    Mat gray(image.rows, image.cols, CV_8UC1);
    for(int i = 0; i < image.rows; i++){
        for(int j = 0; j < image.cols; j++){
            Vec3b pixel = image.at<Vec3b>(i, j);
            //OpenCV usa el orden de color BGR
            uchar b = pixel[0];
            uchar g = pixel[1];
            uchar r = pixel[2];
            gray.at<uchar>(i, j) = (b + g + r) / 3;
        }
    }
    return gray;
}

Mat Filtros::recortarImg(Mat img, int largo, int alto, int x, int y){
    Rect corte(x,y,largo, alto);
    Mat recortada = img(corte);
    return recortada;
}

Mat Filtros::Umbralizacion(Mat img, int umbral){
    Mat binarizada = Mat::zeros(img.size(), img.type());
    for(int i = 0; i<img.rows; i++){
        for(int j = 0; j <img.cols; j++){
            Vec3b pixel = img.at<Vec3b>(i, j);
            int r=pixel.val[2];
            int g=pixel.val[1];
            int b=pixel.val[0];
            if(r>umbral){pixel.val[2]=0;}else{pixel.val[2]=255;}
            if(g>umbral){pixel.val[1]=0;}else{pixel.val[1]=255;}
            if(b>umbral){pixel.val[0]=0;}else{pixel.val[0]=255;}
            binarizada.at<Vec3b>(i, j) = pixel;
        }
    }
    return binarizada;
}

Mat Filtros::negativo(Mat img){
    Mat aux = Mat::zeros(img.size(), img.type());
    for(int x=0; x<img.rows;x++){
        for(int y=0; y<img.cols;y++){
            Vec3b pixel = img.at<Vec3b>(x, y);
            int r = pixel.val[2];
            int g = pixel.val[1];
            int b = pixel.val[0];
            pixel.val[0]=255-b;
            pixel.val[1]=255-g;
            pixel.val[2]=255-r;
            aux.at<Vec3b>(x, y) = pixel;
        }
    }
    return aux;
}

int Filtros::validar(int i){
    if(i<0)return 0;
    if(i>255)return 255;
    return i;
}

Mat Filtros::expansionLineal(int r1, int r2, Mat imagen){
    Mat aux = Mat::zeros(imagen.size(), imagen.type());
    for(int x=0; x< imagen.rows;x++){
        for(int y=0; y<imagen.cols;y++){
            Vec3b pixel = imagen.at<Vec3b>(x, y);
            int r = validar((pixel.val[2] - r1) * (255/(r2-r1)));
            int g = validar((pixel.val[1] - r1) * (255/(r2-r1)));
            int b = validar((pixel.val[0] - r1) * (255/(r2-r1)));
            pixel.val[0]=b;
            pixel.val[1]=g;
            pixel.val[2]=r;
            aux.at<Vec3b>(x, y) = pixel;
        }
    }
    return aux;
}

void Filtros::calcularFrecuencias(Mat imagen, int color, double frecuencias[]){
    for(int x=0; x<imagen.rows;x++){
        for(int y=0; y<imagen.cols;y++){
            Vec3b pixel = imagen.at<Vec3b>(x, y);
            int r=pixel.val[2];
            int g=pixel.val[1];
            int b=pixel.val[0];
            //cout << "frecuencias: "<<frecuencias[r]<<"    , r: "<< r << endl;
            if(color == 1){frecuencias[r]++;}
            if(color == 2){frecuencias[g]++;}
            if(color == 3){frecuencias[b]++;}
        }
    }
}

int Filtros::calcularMinimo(double frecuencias[]){
    for(int x=0; x<256; x++){
        if(frecuencias[x]!=0){return x;}
    }
    return -1;
}

int Filtros::calcularMaximo(double frecuencias[]){
    for(int x=255; x>=0; x--){
        if(frecuencias[x]!=0){return x;}
    }
    return -1;
}

void Filtros::Histograma(double frecuencias[]){
    vector<double> r;
    Gnuplot g1;
    for(int i=0; i<255; i++){
        r.push_back((double)frecuencias[i]);
    }
    g1.set_smooth().plot_x(r,"Tonos");
    g1.unset_smooth();
    cin.clear();
    cin.ignore(cin.rdbuf()->in_avail());
    cin.get();
}

void Filtros::Histograma_RGB(Mat img){
    vector<double> r,g,b;
    Gnuplot g1;
    double r_[256]={0};
    double g_[256]={0};
    double b_[256]={0};
    calcularFrecuencias(img, 1, r_);
    calcularFrecuencias(img, 2, g_);
    calcularFrecuencias(img, 3, b_);
    for(int i=0; i<255; i++){
        r.push_back((double)r_[i]);
        g.push_back((double)g_[i]);
        b.push_back((double)b_[i]);
    }
    g1.set_smooth().plot_x(r,"R");
    g1.set_smooth().plot_x(g,"G");
    g1.set_smooth().plot_x(b,"B");
    g1.unset_smooth();
    cin.clear();
    cin.ignore(cin.rdbuf()->in_avail());
    cin.get();
}

int Filtros::reajustarUmbral(int ui, double histograma[]){
    int u1,u2,a1=0,a2=0,n1=0,n2=0;
    a1+=histograma[0];
    for(int x=1;x<ui;x++){
        a1+=histograma[x]*x;
        n1+=histograma[x];
    }
    for(int y=ui;y<=255;y++){
        a2+=histograma[y]*y;
        n2+=histograma[y];
    }
    if (n1==0 || n2==0) return 0;
    u1 = a1/n1;
    u2 = a2/n2;
    return (int)((u1+u2)/2);
}

int Filtros::calcular_Umbral_Automatico(double histograma[]){
    int numPixels = 0, suma = 0;
    for(int x=0; x<256; x++){
        numPixels+=histograma[x];
        suma+=histograma[x]*x;
    }
    int umbralInicial=(int)(suma/numPixels);
    int ui = umbralInicial, uNuevo=0;
    do{
        uNuevo = ui;
        ui = reajustarUmbral(ui,histograma);
    }while(uNuevo!=ui);
    return ui;
}

Mat Filtros::umbralizacion_otsu(Mat img){
    Mat bina=e_Grises(img);
    Mat r;
    threshold(bina, r, 0, 255, THRESH_BINARY_INV | THRESH_OTSU);
    return r;
}

int Filtros::contar(Mat imagen){
    Mat img;
    cvtColor(imagen, img, COLOR_BGR2GRAY);
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    findContours(img, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0));
    vector<double> areas(contours.size());
    for(int i = 0; i < contours.size(); i++){
        areas[i] = contourArea(contours[i]);
    }

    return contours.size();
}

Mat Filtros::erosion(Mat img){
    Mat er, kernel=getStructuringElement(MORPH_CROSS, Size(3,3));
    erode(img, er, kernel);
    return er;
}
