#include <vector>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <vector>
#include "PuntoInicial.h"

using namespace std;
using namespace cv;

PuntoInicial::PuntoInicial(){}

int PuntoInicial::getCoordenadaX(){
    return coordenadaX;
}

int PuntoInicial::getCoordenadaY() {
    return coordenadaY;
}

int PuntoInicial::getValor(){
    return valor;
}

int PuntoInicial::getNumeroRegion(){
    return numeroRegion;
}

bool PuntoInicial::isVisitado() {
    return visitado;
}

void PuntoInicial::setCoordenadaX(int coordenadaX) {
    coordenadaX = coordenadaX;
}

void PuntoInicial::setCoordenadaY(int coordenadaY) {
    coordenadaY = coordenadaY;
}

void PuntoInicial::setVisitado(bool visitado) {
    visitado = visitado;
}

void PuntoInicial::setValor(int valor){
    valor = valor;
}

void PuntoInicial::setNumeroRegion(int numeroRegion){
    numeroRegion = numeroRegion;
}
