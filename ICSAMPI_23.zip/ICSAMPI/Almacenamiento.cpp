#include "Almacenamiento.h"
#include <iostream>
/*
Almacenamiento::Almacenamiento(){}

void Almacenamiento::gestionBD_almacenar(string nImg, int conteo, int porcentaje){
    cout << "0";
    try{
        sql::Driver *driver;
        sql::Connection *con;
        sql::Statement *stmt;
        sql::ResultSet *res;
        sql::PreparedStatement *pstmt;
        cout << "1";
        /* Create a connection */
        /*driver = get_driver_instance();
        con = driver->connect("tcp://127.0.0.1:3306", "os", "fldsmdfr");
        /* Connect to the MySQL test database */
        /*con->setSchema("ICSAMPI");
        cout << "2";
        /* '?' is the supported placeholder syntax */
       /* pstmt = con->prepareStatement("INSERT INTO Semilla_identificada(id_imgConteo, conteo, porcentaje) VALUES ('nImg', 'conteo', 'porcentaje')");
        delete pstmt;

    }catch(sql::SQLException &e){cout << "Error conexión a BD";}
}

void Almacenamiento::gestionBD_consulta(){}

*/
