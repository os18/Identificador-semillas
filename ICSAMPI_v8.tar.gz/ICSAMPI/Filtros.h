#ifndef FILTROS_H_INCLUDED
#define FILTROS_H_INCLUDED
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>

using namespace cv;
using namespace std;

class Filtros{
    public:
        Filtros();
        ~Filtros();
        Mat e_Grises(Mat);
        Mat ecualizacion(Mat);
        Mat convolucion(int, Mat);
        Mat binarizacion(Mat, int);
        Mat iluminacion(Mat, int);
        Mat contraste_clahe(Mat);
        void histograma(Mat, int);
        Mat recortarImg(Mat, int, int);
};

Filtros::Filtros(){} //constructor

Filtros::~Filtros(){} //destructor

Mat Filtros::e_Grises(Mat image){
    Mat gray(image.rows, image.cols, CV_8UC1);
    for(int i = 0; i < image.rows; i++){
        for(int j = 0; j < image.cols; j++){
            Vec3b pixel = image.at<Vec3b>(i, j);
            //OpenCV usa el orden de color BGR
            uchar b = pixel[0];
            uchar g = pixel[1];
            uchar r = pixel[2];
            gray.at<uchar>(i, j) = (b + g + r) / 3;
        }
    }
    return gray;
}

void Filtros::histograma(Mat m, int color) {
    ///Separar la imagen en sus planos BGR.
    vector<Mat> bgr_planes;
    split( m, bgr_planes );

    /// Establecer el rango de valores entre 0 y 255 y crear objetos para guardar los histogramas
    int histSize = 256;
    float range[] = { 0, 256 } ;
    const float* histRange = { range };
    bool uniform = true; bool accumulate = false;
    Mat b_hist, g_hist, r_hist;
    int hist_w = 512; int hist_h = 400;
    int bin_w = cvRound((double) hist_w/histSize);
    Mat histImage(hist_h, hist_w, CV_8UC3, Scalar(0,0,0)); /// Se crea una imagen para mostrar los histogramas.

    if(color == 0){ ///azul
        ///Calculando los histogramas(matriz origen, num matrices, canal a medir, mascara(si no esta definido no se usa),
        ///objeto donde se almacena el hist, dimensionalidad del hist, num de contenedores, rango de valores a medir, tamaño uniforme, inicio en limpio)
        calcHist( &bgr_planes[0], 1, 0, Mat(), b_hist, 1, &histSize, &histRange, uniform, accumulate);
        ///normaliza el histograma(matriz entrada, matriz normalizada, limite sup, lim inf, tipo de normalizacion, matriz normalizada del mismo tipo que entrada, mascara opcional)
        normalize(b_hist, b_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
        ///dibujar para cada canal y mostrar histograma
        for( int i = 1; i < histSize; i++){
              line( histImage, Point( bin_w*(i-1), hist_h - cvRound(b_hist.at<float>(i-1)) ) ,Point( bin_w*(i), hist_h - cvRound(b_hist.at<float>(i)) ), Scalar( 255, 0, 0), 2, 8, 0  );
        }
    }else if(color == 1){ ///verde
        calcHist( &bgr_planes[1], 1, 0, Mat(), g_hist, 1, &histSize, &histRange, uniform, accumulate);
        normalize(g_hist, g_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
        for( int i = 1; i < histSize; i++){
              line(histImage, Point( bin_w*(i-1), hist_h - cvRound(g_hist.at<float>(i-1))) ,Point(bin_w*(i), hist_h - cvRound(g_hist.at<float>(i))), Scalar(0, 255, 0), 2, 8, 0);
        }
    }else if(color == 2){ ///rojo
        calcHist(&bgr_planes[2], 1, 0, Mat(), r_hist, 1, &histSize, &histRange, uniform, accumulate);
        normalize(r_hist, r_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
        for( int i = 1; i < histSize; i++){
              line(histImage, Point( bin_w*(i-1), hist_h - cvRound(r_hist.at<float>(i-1))) ,Point(bin_w*(i), hist_h - cvRound(r_hist.at<float>(i))), Scalar(0, 0, 255), 2, 8, 0);
        }
    }else if(color == 3){ ///bgr
        calcHist(&bgr_planes[0], 1, 0, Mat(), b_hist, 1, &histSize, &histRange, uniform, accumulate);
        calcHist(&bgr_planes[1], 1, 0, Mat(), g_hist, 1, &histSize, &histRange, uniform, accumulate);
        calcHist(&bgr_planes[2], 1, 0, Mat(), r_hist, 1, &histSize, &histRange, uniform, accumulate);
        normalize(b_hist, b_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
        normalize(g_hist, g_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
        normalize(r_hist, r_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
        for( int i = 1; i < histSize; i++){
            line(histImage, Point(bin_w*(i-1), hist_h - cvRound(b_hist.at<float>(i-1))) ,Point(bin_w*(i), hist_h - cvRound(b_hist.at<float>(i))), Scalar(255, 0, 0), 2, 8, 0  );
            line(histImage, Point(bin_w*(i-1), hist_h - cvRound(g_hist.at<float>(i-1))) ,Point(bin_w*(i), hist_h - cvRound(g_hist.at<float>(i))), Scalar(0, 255, 0), 2, 8, 0);
            line(histImage, Point(bin_w*(i-1), hist_h - cvRound(r_hist.at<float>(i-1))) ,Point(bin_w*(i), hist_h - cvRound(r_hist.at<float>(i))), Scalar(0, 0, 255), 2, 8, 0);
        }
    }

    namedWindow("Histograma", WINDOW_AUTOSIZE );
    imshow("Histograma", histImage);
    waitKey(0);
}

Mat Filtros::recortarImg(Mat img, int largo, int alto){
    //cout <<"tamImagen: "<<img.size<< endl;
    //cout <<"cols: "<<img.cols<<", "<<img.rows<< endl;
    Rect corte(0,0,largo, alto);
    Mat recortada = img(corte);
}

Mat Filtros::binarizacion(Mat img, int umbral){
    threshold(img, img, umbral, 255, THRESH_BINARY);
    return img;
}

/*Mat Filtros::binarizacion(Mat img, int umbral){
    Mat binarizada;
    adaptiveThreshold(img, binarizada, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 3, 0);
    namedWindow("Adaptative bin", WINDOW_AUTOSIZE );
    imshow("Adaptative bin", binarizada);
    waitKey(0);
    return binarizada;
}*/

/*Mat Filtros::binarizacion(Mat img, int umbral){
    Mat binarizada = Mat::zeros(img.size(), img.type());
    for(int i = 0; i < img.rows; i++){
        for(int j = 0; j < img.cols; j++){
            Vec3b pixel = img.at<Vec3b>(i, j);
            int b=pixel.val[0];
            if(b>umbral){
                pixel.val[0]=255;
                pixel.val[1]=255;
                pixel.val[2]=255;
                binarizada.at<Vec3b>(i, j) = pixel;
            }else{
                pixel.val[0]=0;
                pixel.val[1]=0;
                pixel.val[2]=0;
                binarizada.at<Vec3b>(i, j) = pixel;
            }
        }
    }
    return binarizada;
}*/

/*Mat Filtros::iluminacion(Mat img){
    Mat new_image = Mat::zeros(image.size(), image.type());
    double a=1.0;
    int b=0;
    cout << "* Enter the alpha value [1.0-3.0]: "; cin >> a;
    cout << "* Enter the beta value [0-100]: ";    cin >> b;
    for(int y = 0; y < image.rows; y++){
        for(int x = 0; x < image.cols; x++){
            for(int c = 0; c < 3; c++){
                new_image.at<Vec3b>(y,x)[c] = saturate_cast<uchar>(a*(image.at<Vec3b>(y,x)[c]) + b );
            }
        }
    }
}*/


/*Mat Filtros::iluminacion(Mat img, int vIlum){
    Mat iluminada; //= Mat::zeros(img.size(), img.type());
    img.convertTo(iluminada, -1, 1, vIlum);
    return iluminada;
}*/


Mat Filtros::contraste_clahe(Mat img){
    Ptr<CLAHE> clahe = createCLAHE();
    clahe->setClipLimit(2);
    Mat dst;
    clahe->apply(img,dst);

    return dst;
}

#endif // FILTROS_H_INCLUDED
