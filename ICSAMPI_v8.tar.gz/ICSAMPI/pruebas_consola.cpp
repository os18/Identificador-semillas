#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"

using namespace std;
using namespace cv;

int main(){
    cout<< "Identificación y conteo de semillas de ajo mediante procesamiento de imgenes"<<endl;
    //string dir("/home/os/Pictures/Fondos/birds.jpg");
    //string dir("/home/os/Pictures/Fondos/lead_960.jpg");
    string dir("/home/os/Documents/Proyectos/Proyecto_TT/Pruebas/Originales/DJI_0289.JPG");
    Gestor g(dir);
    g.cargarImagen();

    if(!(g.obtenerImagen().empty())){
        Mat original=g.obtenerImagen();
        g.visualizar(original);
        Filtros f;
        Mat grises2=f.e_Grises(original);

        Mat binarizada=f.binarizacion(grises2, 250);
        g.guardarImagen(binarizada, "/home/os/Documents/Proyectos/Proyecto_TT/Pruebas/bin-simple_umbral-250.jpg");
        g.visualizar(binarizada);
    }
    cout << "Fin del programa" << endl;
    return 0;
}

