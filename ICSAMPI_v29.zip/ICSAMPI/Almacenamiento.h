#ifndef ALMACENAMIENTO_H
#define ALMACENAMIENTO_H

#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>
#include <mysql_connection.h>
#include <mysql/mysql.h>
#include <mysql/mysqld_error.h>
#include <iostream>
#include <string>

using namespace std;
using namespace sql;

class Almacenamiento{
    public:
        Almacenamiento();
        void gestionBD_almacenar(string, int, int);
};

#endif // ALMACENAMIENTO_H
