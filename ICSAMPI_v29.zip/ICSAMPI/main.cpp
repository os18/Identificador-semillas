#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"
#include "Contador.h"
#include "Convolucion.h"
#include "Almacenamiento.h"

using namespace std;
using namespace cv;

int main(){
    string dir("/home/os/Documents/Proyectos/ICSAMPI/img/parcela/IP_1.JPG");
    Gestor g(dir);
    g.cargarImagen();

    if(!(g.obtenerImagen().empty())){
        Mat original=g.obtenerImagen();
        Filtros f;
        g.visualizar(original, "Original");
    }
    cout << "Fin del programa" << endl;
    return 0;
}
