#ifndef PUNTOINICIAL_H_INCLUDED
#define PUNTOINICIAL_H_INCLUDED

#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <vector>
#include <vector>

using namespace std;
using namespace cv;

class PuntoInicial{
    private:
        int valor = 0;
        int numeroRegion= 0;
        int coordenadaX = 0;
        int coordenadaY = 0;
        bool visitado = false;

    public:
        PuntoInicial();
        int getCoordenadaX();
        int getCoordenadaY();
        int getValor();
        int getNumeroRegion();
        bool isVisitado();
        void setCoordenadaX(int);
        void setCoordenadaY(int);
        void setVisitado(bool);
        void setValor(int);
        void setNumeroRegion(int);
};

#endif // PUNTOINICIAL_H_INCLUDED
