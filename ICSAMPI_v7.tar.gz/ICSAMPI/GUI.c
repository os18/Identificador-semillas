/*#include <gtk/gtk.h>
#include <stdbool.h>
//#include <string>
#include "Gestor.h"
/*
char *archivo;
using namespace std;



static void open_dialog(GtkButton* btn_seleccion, gpointer user_data){
    GtkWidget *imagen = GTK_WIDGET (user_data);
    GtkWidget *toplevel = gtk_widget_get_toplevel (imagen);
    GtkFileFilter *filtro = gtk_file_filter_new();
    GtkWidget *dialog =gtk_file_chooser_dialog_new("Selecciona una imagen",GTK_WINDOW(toplevel),GTK_FILE_CHOOSER_ACTION_OPEN,
                                                    ("_CANCEL"),GTK_RESPONSE_CANCEL,("_OPEN"),GTK_RESPONSE_ACCEPT,NULL);
    gtk_file_filter_add_pixbuf_formats(filtro);
    gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), filtro);
    gtk_widget_show_all(dialog);
    switch (gtk_dialog_run (GTK_DIALOG (dialog))){
		case GTK_RESPONSE_ACCEPT:{
			gchar *filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
            String auxStg(filename);
            Filtros f;
            Gestor g;
            Mat img = imread(auxStg, IMREAD_COLOR);
            Mat auxImg=f.recortarImg(img, 100, 100);
            g.guardarImagen(auxImg, "/home/os/Documents/TT/temp_recortada.jpg");
            gchar *diraux="/home/os/Documents/TT/temp_recortada.jpg";
			gtk_image_set_from_file(GTK_IMAGE (imagen), diraux);
			break;
		}default:
			break;
	}
	gtk_widget_destroy (dialog);
}

int main(int argc, char *argv[]) {
    GtkWidget *tabla_cont; //contenedor de los elementos (widget) en la ventana
    GtkWidget *ventana;
    GtkWidget *imagen;
    GtkWidget *btn_seleccion, *btn_ver, *btn_identificar, *btn_almacenar;
    GtkWidget *logo; //

    gtk_init(&argc, &argv);

    //crear ventana1
    ventana = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_position(GTK_WINDOW(ventana), GTK_WIN_POS_CENTER);
    gtk_window_set_default_size(GTK_WINDOW(ventana), 160, 80);
    //titulo de la ventana
    gtk_window_set_title(GTK_WINDOW(ventana), "Identificador semilla");
    //estableciendo el borde de la ventana
    gtk_container_set_border_width(GTK_CONTAINER(ventana), 10);

    //contenedor para los wigdet
    tabla_cont = gtk_grid_new();

    //se agrega el contenedor a la ventana
    gtk_container_add(GTK_CONTAINER(ventana),tabla_cont);

    //la imagen de logo de agrega en la primera fila
    logo = gtk_image_new_from_file ("/home/os/Documents/TT/logo_.png");
    gtk_widget_set_hexpand(logo, FALSE);
    gtk_grid_attach(GTK_GRID(tabla_cont),logo, 5,0,1,1);

    btn_seleccion = gtk_button_new_with_label("Selecciona una imagen");
    gtk_widget_set_hexpand(btn_seleccion, FALSE);
    gtk_grid_attach(GTK_GRID(tabla_cont), btn_seleccion,5,1,1,1);

    imagen=gtk_image_new_from_file("/home/os/Documents/TT/fondo.jpg");
    gtk_grid_attach(GTK_GRID(tabla_cont), imagen, 0,0,3,8);

    btn_ver=gtk_button_new_with_label("Ver imagen");
    gtk_grid_attach(GTK_GRID(tabla_cont), btn_ver, 5,3,1,1);

    btn_identificar=gtk_button_new_with_label("Identificar semilla");
    gtk_grid_attach(GTK_GRID(tabla_cont), btn_identificar, 5,5,1,1);

    btn_almacenar=gtk_button_new_with_label("Almacenar");
    gtk_grid_attach(GTK_GRID(tabla_cont), btn_almacenar, 5,7,1,1);

    //señales y eventos
    g_signal_connect(G_OBJECT(btn_seleccion), "clicked", G_CALLBACK(open_dialog), imagen);

    g_signal_connect(G_OBJECT(ventana), "destroy", G_CALLBACK(gtk_main_quit), NULL);


    //mostrar
    gtk_widget_show_all(ventana);
    gtk_main();

    return 0;
}
*/
