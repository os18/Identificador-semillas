#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"

using namespace std;
using namespace cv;

int main(){
    cout<< "Identificación y conteo de semillas de ajo mediante procesamiento de imgenes"<<endl;
    //string dir("/home/os/Pictures/Fondos/birds.jpg");
    //string dir("/home/os/Pictures/Fondos/lead_960.jpg");
    string dir("/home/os/Documents/Proyectos/Proyecto_TT/Pruebas/Originales/DJI_0234.JPG");
    Gestor g(dir);
    g.cargarImagen();

    if(!(g.obtenerImagen().empty())){
         Mat original=g.obtenerImagen();
         g.visualizar(original);
         Filtros f;
         Mat grises2=f.e_Grises(original);
         //g.visualizar(grises2);
         //Mat binarizada2=f.binarizacion(grises2, 230);
         //string direcorio("/home/os/Documents/Proyectos/Proyecto_TT/Pruebas/grises-binarizacion_u200_2.JPG");
         //g.guardarImagen(binarizada2, direcorio);
         //g.visualizar(binarizada2);

         //Mat binarizada_1=f.binarizacion_1(grises2, 230);
         //g.visualizar(binarizada_1);

         //iluminacion
         //Mat iluminada = f.iluminacion(original, 0);
         //g.visualizar(iluminada);

         //otra vez binari
         //Mat aux=f.binarizacion(iluminada, 230);
         //g.visualizar(aux);

         Mat var=f.iluminacion_2(original, 10);
         g.visualizar(var);

            f.histograma(original, 0);

         Mat var2=f.binarizacion(var, 200);
         g.visualizar(var2);

         f.histograma(grises2, 0);
    }
    cout << "Fin del programa" << endl;
    return 0;
}

