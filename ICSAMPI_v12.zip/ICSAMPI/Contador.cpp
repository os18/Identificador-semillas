//#include "Contador.h"

#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include <opencv2/opencv.hpp>
//#pragma comment(lib, "opencv_world331.lib")
#include <iostream>
#include <vector>
#include "Gestor.h"


using namespace std;
using namespace cv;

int main(void){
    Mat img = imread("/home/os/Documents/IPP.JPG", IMREAD_GRAYSCALE);


    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    findContours(img, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0));
    vector<double> areas(contours.size());
    for(int i = 0; i < contours.size(); i++)
        areas[i] = contourArea(contours[i]);

    /*vector<Point2d> mass_centres(contours.size());
    for (int i = 0; i < contours.size(); i++){
        const Moments mu = moments(contours[i], false);
        mass_centres[i] = Point2d(mu.m10 / mu.m00, mu.m01 / mu.m00);
    }*/

    cout << "Num particles: " << contours.size() << endl;

    /*for (int i = 0; i < contours.size(); i++)
        cout << "centre " << (i + 1) << ": " << mass_centres[i].x << " " << mass_centres[i].y << endl;*/

    return 0;
}
