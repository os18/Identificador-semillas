#ifndef FILTROS_H_INCLUDED
#define FILTROS_H_INCLUDED

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>

using namespace std;
using namespace cv;

class Filtros{
    public:
        Filtros();
        ~Filtros();
        Mat e_Grises(Mat);
        Mat binarizacion(Mat, int);
        Mat umbralizacion(Mat, int, int, int);
        void histograma(Mat, int);
        Mat recortarImg(Mat, int, int);
        //otros filtros
        Mat gradiente(Mat);
        Mat marcadores_internos(Mat);
        Mat apertura(Mat);
        Mat cierre(Mat);
        Mat dilatacion(Mat);
        Mat erosion(Mat);
        Mat grad_morf(Mat);
};

#endif // FILTROS_H_INCLUDED
