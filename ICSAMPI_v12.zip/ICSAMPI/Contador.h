#ifndef CONTADOR_H
#define CONTADOR_H


class Contador{
    public:
        Contador();

    private:
        int contar(Mat img);
};

#endif // CONTADOR_H
