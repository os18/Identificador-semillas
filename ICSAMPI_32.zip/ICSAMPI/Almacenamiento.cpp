#include "Almacenamiento.h"

Almacenamiento::Almacenamiento(){}

void Almacenamiento::gestionBD_almacenar(string id_imgConteo, int conteo, int porcentaje){
    MYSQL * _mysql;
        /* Intentar iniciar un objeto MySQL */
        if(!(_mysql = mysql_init(0))){
            cout << "Error al crear el objeto mysql" << endl;
        }else{
            cout << "Objeto mysql creado correctamente, conectando ..." << endl;
            /* Intentar conectar al servidor mysql */
            if(!mysql_real_connect(_mysql, "localhost", "os", "fldsmdfr", "ICSAMPI", 3306, NULL, 0)){
                cout << "No es posible conectar al servidor" << endl;
            }else{
                cout << "Conectado al servidor ..." << endl;
                const char * sql = "SELECT * FROM Semilla";
                int query = mysql_query(_mysql, sql);
                if (query != 0){
                    cout << "Ha ocurrido un error al realizar la consulta" << endl;
                }else{
                      cout << "Consulta correcta, insertando datos..." << endl;
                      char *consulta;
                      //char patronnombre[] = "INSERT INTO Semilla_identificada (id_imgConteo, conteo, porcentaje) VALUES(\'holi\', \'10\',\'90\')";
                      mysql_query(_mysql, "INSERT INTO Semilla_identificada (id_imgConteo, conteo, porcentaje) VALUES " "('uju'), " "('10'), " "('90')");
                      // Liberar el resultado de la consulta
                }
                mysql_close(_mysql);
            }
        }
}
