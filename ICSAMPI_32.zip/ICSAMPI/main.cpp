#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"
#include "Contador.h"
#include "Convolucion.h"
#include "Almacenamiento.h"
#include "DeteccionLineas.h"

using namespace std;
using namespace cv;

int main(){
    string dir("/home/os/Documents/Proyectos/ICSAMPI/img/parcela/IP_1.JPG");
    Gestor g(dir);
    g.cargarImagen();

    if(!(g.obtenerImagen().empty())){
        Mat original=g.obtenerImagen();
        Filtros f;
        Mat eGrises=f.e_Grises(original);
        g.visualizar(original, "Original");
        //Mat gblur=f.gaussian_blur(original);
        //g.visualizar(gblur,"gaussian blur");
        //g.guardarImagen(gblur, "/home/os/Documents/Pruebas/GaussianBlur3-3.JPG");

        //Mat er=f.erosion(original);
        //g.visualizar(er, "er1");
        //g.guardarImagen(er, "/home/os/Documents/Pruebas/erosion_MCross3-3.JPG");

        /*Mat apertura=f.apertura(original);
        g.visualizar(apertura, "apertura");
        g.guardarImagen(apertura, "/home/os/Documents/Pruebas/apertura_MCross5-5.JPG");*/

        /*for(int i=0; i<original.cols; i++){
            for(int j=0; j<original.rows; j++){
                Vec3b pixel = original.at<Vec3b>(i, j);
                uchar b = pixel.val[0];
                cout << " " << b;
            }
            cout << endl;
        }*/

        //f.Histograma_RGB(eGrises);

        Convolucion c(eGrises);
        double matriz[]={1,2,1,
                         2,4,2,
                         1,2,1};
        c.asignarMatriz(matriz);
        Mat conv=c.aplicar();
        g.visualizar(conv, "Convolucion");
        for(int i=0; i<conv.rows; i++){
            for(int j=0; j<conv.rows; j++){
                Vec3b pixel = conv.at<Vec3b>(i, j);
                int r=pixel.val[2];
                cout << " " <<r;
            }
            cout <<endl;
        }
        Mat um=f.Umbralizacion(conv, 100);
        g.visualizar(um, "Umbral 100");
//        g.guardarImagen(conv, "/home/os/Documents/Pruebas/convolucion_gaussian3-3.JPG");

        f.Histograma_RGB(original);
        //DeteccionLineas dt;
        //Mat ht_1=dt.transformada_Hough_1(eGrises);
        //g.visualizar(ht_1, "hough probabilistico");

    }
    cout << "Fin del programa" << endl;
    return 0;
}

