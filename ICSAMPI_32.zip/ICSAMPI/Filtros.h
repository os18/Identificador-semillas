#ifndef FILTROS_H_INCLUDED
#define FILTROS_H_INCLUDED

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include <math.h>
#include <stdlib.h>
#include <vector>
#include <cmath>

using namespace std;
using namespace cv;

class Filtros{
    public:
        Filtros();
        Mat e_Grises(Mat);
        Mat Umbralizacion(Mat, int);
        Mat recortarImg(Mat, int, int, int, int);
        Mat expansionLineal(int, int, Mat);
        Mat umbralizacion_otsu(Mat);
        void Histograma(double []);
        void Histograma_RGB(Mat);
        void calcularFrecuencias(Mat, int, double[]);
        int validar(int);
        Mat erosion(Mat);
        Mat apertura(Mat);
        Mat gaussian_blur(Mat);

};

#endif // FILTROS_H_INCLUDED
