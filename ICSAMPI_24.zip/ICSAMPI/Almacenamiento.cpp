#include "Almacenamiento.h"
#include <iostream>

using namespace sql;

Almacenamiento::Almacenamiento(){}

void Almacenamiento::gestionBD_almacenar(string id_imgConteo, int conteo, int porcentaje){
    cout << "0";
    try{
        Driver *driver;
        Connection *con;
        ResultSet *res;
        PreparedStatement *pstmt;
        //Create a connection
        driver = get_driver_instance();
        con = driver->connect("tcp://127.0.0.1:3306", "os", "fldsmdfr");
        con->setSchema("ICSAMPI");
        cout << "2";
        pstmt = con->prepareStatement("INSERT INTO Semilla_identificada(id_imgConteo, conteo, porcentaje) VALUES ('id_imgConteo', 'conteo', 'porcentaje')");
        delete pstmt;

    }catch(sql::SQLException &e){cout << "Error conexión a BD";}
}

void Almacenamiento::gestionBD_consulta(){}
