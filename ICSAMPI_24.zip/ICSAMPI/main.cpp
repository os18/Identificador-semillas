#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"
#include "Contador.h"
#include "Convolucion.h"
#include "Almacenamiento.h"


using namespace std;
using namespace cv;

int main(){
    cout<< "Identificación y conteo de semillas de ajo mediante procesamiento de imgenes"<<endl;
    //string dir("/home/os/Documents/TT/ReporteTT2_LaTeX/Imagenes/IP_3.JPG");
    //string dir("/home/os/Documents/TT/ReporteTT2_LaTeX/Imagenes/Conteo/8.jpg");

    string dir("/home/os/Documents/TT/ReporteTT2_LaTeX/Imagenes/Pruebas/IP6_umbraliz_expM.jpg");
    Gestor g(dir);
    g.cargarImagen();

    if(!(g.obtenerImagen().empty())){
        Mat original=g.obtenerImagen();
        Filtros f;
        g.visualizar(original, "Original");
        ///expansión lineal
        /*Mat exMan=f.expansionLineal(200,255, original);
        g.visualizar(exMan, "manual");
        ///umbralización otsu
        Mat umotsu_manual=f.umbralizacion_otsu(exMan);
        g.visualizar(umotsu_manual, "umbralizacion otsu");
        Mat neg=f.negativo()
        //Convolucion c(umotsu_manual);*/
        /*Mat er=f.erosion(original);
        g.visualizar(er, "eros");
        Mat b=f.Umbralizacion(er, 10);*/

        ///contador
        /*int x=original.cols;
        int y=original.rows;
        Contador c(original, 0,0, x, y);
        cout << "holi "<< endl;
        c.Contar();
        int conteo=c.getEuler();
        cout << "conteo: " << conteo << endl;*/

       /* Mat neg=f.negativo(original);
        g.visualizar(neg, "negat");
        double kernel[di2][dim]={{1,1,1},{1,1,1},{1,1,1}};
        Convolucion cv(neg, kernel);
        Mat con=cv.aplicar();
        g.visualizar(con, "convolucion");*/
        Almacenamiento a;
        a.gestionBD_almacenar("img", 10, 90);


    }
    cout << "Fin del programa" << endl;
    return 0;
}
