#ifndef MATRIZ_H
#define MATRIZ_H


class Matriz
{
    public:
        Matriz();

    protected:

    private:
};

#endif // MATRIZ_H
