#ifndef CONTADOR_H
#define CONTADOR_H

#include <vector>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <vector>
#include "PuntoInicial.h"

#define tam 2
/*
using namespace std;
using namespace cv;

template<typename T> inline size_t Countof(const T (&)) {return 0;}
template<typename T, size_t S> inline size_t Countof(const T (&)[S]) {return S;}

class Contador{
    private:
        Mat imagen;
        int mascara[tam][tam]={{1,1},{1,1}};
        int cX = 0;
        int cY = 0;
        int referenciaRegion = 0;
        double euler;
        int** arregloImagen;
        //vector<vector<PuntoInicial>> imagenAux;
        //vector<vector<int>> arregloImagen;

    public:
        Contador(Mat, int, int, int, int);
        int erosionPixel(int, int);
        int calcularCaras(int, int);
        double getEuler();
        void imagen_A_MatrizBinaria(Mat imagen);
        void cambiarVecinos(int, int);
        void obtenerEtiqueta(int, int);
        void Matriz_A_Discreto();
        void Contar();
        vector<PuntoInicial> encontrarVecinos(int, int);
};
*/
#endif // CONTADOR_H
