#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include "Convolucion.h"

using namespace cv;
using namespace std;

Convolucion::Convolucion(Mat img){
    imagenOriginal = img.clone();
}

void Convolucion::asignarMatriz(double k[]){
    for(int i=0; i<dim; i++){
        int aux=0;
        for(int j=0; j<di2; j++){
            kernel[i][j]=k[aux];
            aux++;
        }
    }
}

Mat Convolucion::aplicar(){
    Mat nueva = Mat::zeros(imagenOriginal.size(), imagenOriginal.type());
    for(int x=0; x<imagenOriginal.rows; x++){
        for(int y=0; y<imagenOriginal.cols; y++){
            Vec3b muestra[di2][dim]={0};
            extraerMuestra(x,y,muestra);
            Vec3b pixel = imagenOriginal.at<Vec3b>(x, y);
            if(muestra!=0){
                int color[3]={0};
                convolucionar(muestra,color);
                pixel[2]=color[2];
                pixel[1]=color[1];
                pixel[0]=color[0];
                nueva.at<Vec3b>(x, y) = pixel;
            }else{
                pixel[2]=255;
                pixel[1]=255;
                pixel[0]=255;
                nueva.at<Vec3b>(x, y) = pixel;
            }
        }
    }
    return nueva;
}

void Convolucion::extraerMuestra(int x, int y, Vec3b matriz[][dim]){
    int xx=0, yy=0;
    for(int i=x-(tam_kernel-1)/2; i<=x+(tam_kernel-1)/2; i++){
        for(int j=y-(tam_kernel-1)/2; j<=y+(tam_kernel-1)/2; j++){
            Vec3b pixel = imagenOriginal.at<Vec3b>(i, j);
            matriz[xx][yy] = pixel;
            yy++;
        }
        yy=0;
        xx++;
    }
}

void Convolucion::convolucionar(Vec3b muestra[][dim], int color[]) {
    int acumuladorR = 0, acumuladorG = 0, acumuladorB = 0;
    for(int x=0; x<tam_kernel; x++){
        for(int y=0; y<tam_kernel; y++){
            Vec3b pixel = muestra[x][y];
            acumuladorR+=(kernel[x][y]*pixel.val[2]);
            acumuladorG+=(kernel[x][y]*pixel.val[1]);
            acumuladorB+=(kernel[x][y]*pixel.val[0]);
        }
        acumuladorR/=divisor;
        acumuladorG/=divisor;
        acumuladorB/=divisor;
    }
    color[2]=validar(acumuladorR);
    color[1]=validar(acumuladorG);
    color[0]=validar(acumuladorB);
}

int Convolucion::validar(int valor){
    if(valor<0)return 0;
    if(valor>255)return 255;
    return valor;
}

