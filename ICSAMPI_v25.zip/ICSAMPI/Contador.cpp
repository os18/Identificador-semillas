#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include "Contador.h"
#include "PuntoInicial.h"

using namespace std;
using namespace cv;
/*
Contador::Contador(Mat imagen, int cX, int cY, int t_x, t_y){
    imagen = imagen;
    arregloImagen=new int[imagen.cols][imagen.rows];
    imagen_A_MatrizBinaria(imagen);
    Matriz_A_Discreto();
    cX = cX;
    cY = cY;
}

double Contador::getEuler(){
    return euler;
}

void Contador::imagen_A_MatrizBinaria(Mat imagen){
    for(int X=0; X<imagen.cols; X++) {
        for(int Y=0; Y<imagen.rows; Y++){
            Vec3b pixel = imagen.at<Vec3b>(X, Y);
            int r = pixel.val[2];
            if(r == 0) {
                arregloImagen[X][Y]=1;
            } else{
                arregloImagen[X][Y]=0;
            }
            cout << " " << arregloImagen[X][Y];
        }
        cout << endl;
    }
}

void Contador::Matriz_A_Discreto(){
    //imagenAux = new PuntoInicial[Countof(arregloImagen)][Countof(arregloImagen[0])];
    for(int i=0; i<Countof(arregloImagen); i++){
        for(int j = 0; j< Countof(arregloImagen[i]); j++){
            PuntoInicial nuevoPixel;
            nuevoPixel.setCoordenadaX(i);
            nuevoPixel.setCoordenadaY(j);
            nuevoPixel.setValor(arregloImagen[i][j]);
            imagenAux[i][j] = nuevoPixel;
        }
    }
}

int Contador::erosionPixel(int X, int Y){
    int valorFinal = 1;
    for(int i=0; i<Countof(mascara); i++) {
        if (i>=0 && i<Countof(arregloImagen)) {
            for(int j=0; j<Countof(mascara[i]); j++) {
                if(j>= 0 && j<Countof(arregloImagen[i])) {
                    if(mascara[i][j]==1 && (mascara[i][j] != arregloImagen[X - cX + i][Y - cY + j])) {
                        valorFinal = 0;
                    }
                }
            }
        }
    }
    return valorFinal;
}

int Contador::calcularCaras(int coordenadaX, int coordenadaY){ //*
    int esquinas[][3] = {{1, 0, 1}, {0, 1, 0}, {1, 0, 1}};
    int totalLados = 0, X = 0, Y = 0;
    for(int i = (coordenadaX - 1); i < (coordenadaX + 2); i++) {
        if(i>= 0 && i<Countof(arregloImagen)){
            for(int j=(coordenadaY - 1); j<(coordenadaY + 2); j++) {
                if(j>=0 && j<Countof(arregloImagen[i])){
                    if(arregloImagen[i][j]==0 && esquinas[X][Y]==0) {
                        totalLados++;
                    }
                }
                Y++;
            }
        }
        X++;
        Y=0;
    }
    return totalLados;
}

void Contador::cambiarVecinos(int coordenadaX, int coordenadaY){//*
    vector<PuntoInicial> vecinosMayores = encontrarVecinos(coordenadaX, coordenadaY);
    for(PuntoInicial pixelActual : vecinosMayores){
        imagenAux[pixelActual.getCoordenadaX()][pixelActual.getCoordenadaY()].setVisitado(true);
        imagenAux[pixelActual.getCoordenadaX()][pixelActual.getCoordenadaY()].setNumeroRegion(imagenAux[coordenadaX][coordenadaY].getNumeroRegion());
        cambiarVecinos(pixelActual.getCoordenadaX(), pixelActual.getCoordenadaY());
    }
}

vector<PuntoInicial> Contador::encontrarVecinos(int coordenadaX, int coordenadaY){ //*
    int vecinos[][3] = {{0, 1, 0}, {1, 0, 1}, {0, 1, 0}};
    vector<PuntoInicial> pixelesVecinos;
    int X = 0, Y = 0;
    for(int i = (coordenadaX - 1); i<(coordenadaX + 2); i++) {
        if(i >= 0 && i <Countof(imagenAux)){
            for(int j=(coordenadaY-1); j<(coordenadaY + 2); j++){
                if(j>=0 && j<Countof(imagenAux[i])){
                    if(imagenAux[i][j].getValor() == 1 && vecinos[X][Y] == 1){
                        if(imagenAux[i][j].getNumeroRegion() > imagenAux[coordenadaX][coordenadaY].getNumeroRegion()){
                            PuntoInicial nuevoVecino;
                            nuevoVecino.setCoordenadaX(i);
                            nuevoVecino.setCoordenadaY(j);
                            nuevoVecino.setValor(1);
                            //pixelesVecinos.add(nuevoVecino);
                            pixelesVecinos.push_back(nuevoVecino);
                        }
                    }
                }
                Y++;
            }
        }
        X++;
        Y = 0;
    }
    return pixelesVecinos;
}
///______________
void Contador::obtenerEtiqueta(int coordenadaX, int coordenadaY) {
    int vecinos[][3] = {{0, 1, 0}, {1, 0, 1}, {0, 1, 0}};
    int X = 0, Y = 0;
    int valorMenor = referenciaRegion;
    bool inicio = true;
    for(int i=(coordenadaX - 1); i<(coordenadaX + 2); i++) {
        if (i>= 0 && i<Countof(imagenAux)){
            for (int j = (coordenadaY - 1); j<(coordenadaY + 2); j++) {
                if(j >= 0 && j < Countof(imagenAux[i])) {
                    if(imagenAux[i][j].getValor() == 1 && vecinos[X][Y] == 1) {
                        if(!(i == coordenadaX && j == coordenadaY)) {
                            if (imagenAux[i][j].getNumeroRegion() > 0) {
                                if (imagenAux[i][j].getNumeroRegion() < valorMenor) {
                                    valorMenor = imagenAux[i][j].getNumeroRegion();
                                }
                                inicio = false;
                            }
                        }
                    }
                }
                Y++;
            }
        }
        X++;
        Y = 0;
    }
    if (inicio) {
        imagenAux[coordenadaX][coordenadaY].setVisitado(true);
        imagenAux[coordenadaX][coordenadaY].setNumeroRegion(++referenciaRegion);
    }else {
        imagenAux[coordenadaX][coordenadaY].setVisitado(true);
        imagenAux[coordenadaX][coordenadaY].setNumeroRegion(valorMenor);
        cambiarVecinos(coordenadaX, coordenadaY);
    }
}

void Contador::Contar(){
    int numPR = 0, numMPixels = 0, numCaras = 0;
    referenciaRegion = 0;
    for(int i=0; i<Countof(arregloImagen); i++) {
        for(int j=0; j<Countof(arregloImagen[i]); j++) {
            if(arregloImagen[i][j] == 1){
                numPR++;
                numMPixels += erosionPixel(i, j);
                numCaras += calcularCaras(i, j);
                if(!imagenAux[i][j].isVisitado()) {
                    obtenerEtiqueta(i, j);
                }
            }
        }
    }
    euler = (double) numMPixels - (((2.0 * (double) numPR) - (double) numCaras) / 2.0);
}
*/
